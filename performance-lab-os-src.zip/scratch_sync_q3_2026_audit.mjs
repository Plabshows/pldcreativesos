import fs from 'fs';
import { createClient } from '@supabase/supabase-js';

const envContent = fs.readFileSync('.env.local', 'utf8');
const envVars = Object.fromEntries(
  envContent.split('\n').filter(line => line.includes('=')).map(line => {
    const [k, ...v] = line.split('=');
    return [k.trim(), v.join('=').trim().replace(/^["']|["']$/g, '')];
  })
);

const supabase = createClient(
  envVars.NEXT_PUBLIC_SUPABASE_URL,
  envVars.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || envVars.SUPABASE_SERVICE_ROLE_KEY
);

async function main() {
  console.log('=== INICIANDO AUDITORÍA Y ACTUALIZACIÓN ECONÓMICA DE PERFORMANCE LAB OS (Q3 2026) ===\n');

  // 0. Organización predeterminada
  const orgId = '191c90ad-5337-405e-9d1a-abae2ad8c70e';
  const dummyUserId = '00000000-0000-0000-0000-000000000000';

  // 1. Clientes: Buscar e insertar los que falten
  const clientsToEnsure = [
    { company_name: 'Charley Dobson' },
    { company_name: 'Cream Events SL' },
    { company_name: 'Simran Kaur Chahal' }
  ];

  for (const c of clientsToEnsure) {
    const { data: existing } = await supabase
      .from('clients')
      .select('id')
      .ilike('company_name', `%${c.company_name.split(' ')[0]}%`)
      .limit(1);
    
    if (!existing || !existing.length) {
      console.log(`[CLIENTE] Creando cliente: ${c.company_name}`);
      await supabase.from('clients').insert({
        organization_id: orgId,
        company_name: c.company_name
      });
    }
  }

  // Obtener mapa completo de clientes actualizado
  const { data: clientsData } = await supabase.from('clients').select('id, company_name');
  if (!clientsData?.length) throw new Error('No se pudieron obtener clientes de la DB.');
  const clientMap = new Map(clientsData.map(c => [c.company_name.toUpperCase(), c.id]));
  
  const getClientId = (name) => {
    const upper = name.toUpperCase();
    for (const [k, v] of clientMap.entries()) {
      if (k.includes(upper.split(' ')[0])) return v;
    }
    return clientMap.get(upper) || clientsData[0].id;
  };

  // 2. Facturas: Crear las facturas que no existan aún (053, 054, 055, 056, 057, 058)
  const newInvoices = [
    { number: '053', client: 'Simran Kaur Chahal', total: 80000, base: 80000, status: 'paid', concept: 'Reserva 50% - Evento 23/05/2027 (Proyecto 1.600 €)', issue_date: '2026-09-11' },
    { number: '054', client: 'MUSICALIDAD S.L.', total: 222600, base: 210000, status: 'pending', concept: 'Evento El Puig 05/09/2026', issue_date: '2026-09-15' },
    { number: '055', client: 'Charley Dobson', total: 30000, base: 30000, status: 'pending', concept: 'Mirror / Animal Head Hacienda Na Xamena 10/10/2026', issue_date: '2026-09-15', notes: 'PENDIENTE DE PAGO' },
    { number: '056', client: 'Cream Events SL', total: 47700, base: 45000, status: 'unverified', concept: 'Percusionista Atzaró 01/10/2026 - Anticipo 50% (Proyecto 900 €)', issue_date: '2026-09-15' },
    { number: '057', client: 'CHRISTOPHER HAWKSLEY', total: 120000, base: 120000, status: 'unverified', concept: 'Performances Villa 05/09/2026', issue_date: '2026-09-16' },
    { number: '058', client: 'REMEMBERLAND IBIZA S.L.', total: 137800, base: 130000, status: 'pending', concept: 'Rememberland Amnesia 11/09/2026 (5 artistas x 260 €)', issue_date: '2026-09-16' }
  ];

  for (const inv of newInvoices) {
    const { data: exists } = await supabase.from('invoices').select('id').eq('number', inv.number).maybeSingle();
    if (!exists) {
      console.log(`[FACTURA] Insertando nueva factura ${inv.number} (${inv.client})`);
      const cId = getClientId(inv.client);
      await supabase.from('invoices').insert({
        organization_id: orgId,
        created_by: dummyUserId,
        number: inv.number,
        client_id: cId,
        total_cents: inv.total,
        base_cents: inv.base,
        tax_cents: inv.total - inv.base > 0 ? inv.total - inv.base : 0,
        currency: 'EUR',
        status: inv.status,
        concept: inv.concept,
        issue_date: inv.issue_date,
        due_date: inv.issue_date,
        document_url: '',
        notes: inv.notes || 'Factura creada durante la auditoría del 3T 2026'
      });
    }
  }

  // 3. Actualización de Estados e Importes de Facturas
  console.log('\n[FACTURAS] Actualizando estados y conceptos de las 22 facturas clasificadas...');

  // Facturas Cobro por Verificar
  const unverifiedNumbers = ['018', '019', '038', '049', '056', '057'];
  for (const num of unverifiedNumbers) {
    await supabase.from('invoices').update({ status: 'unverified' }).eq('number', num);
  }

  // Ajuste especial Factura 018: Eliminar cobro automático si existía para mantener los 1.086,50 € como Cobro por Verificar
  const { data: inv018 } = await supabase.from('invoices').select('id').eq('number', '018').maybeSingle();
  if (inv018) {
    await supabase.from('invoice_payments').delete().eq('invoice_id', inv018.id);
  }

  // Facturas Cobradas
  // 037 - Universo Pacha (5.300 €) el 16/09/2026
  const { data: inv037 } = await supabase.from('invoices').select('id, currency, total_cents').eq('number', '037').maybeSingle();
  if (inv037) {
    const { data: pay037 } = await supabase.from('invoice_payments').select('id').eq('invoice_id', inv037.id);
    if (!pay037?.length) {
      await supabase.from('invoice_payments').insert({
        organization_id: orgId,
        created_by: dummyUserId,
        invoice_id: inv037.id,
        amount_cents: inv037.total_cents,
        currency: inv037.currency || 'EUR',
        payment_date: '2026-09-16',
        method: 'Transferencia bancaria',
        reference: 'Cobro localizado 16/09/2026',
        note: 'Cobro verificado el 16/09/2026'
      });
    }
    await supabase.from('invoices').update({ status: 'paid' }).eq('id', inv037.id);
  }

  // 052 - Rememberland (1.929,20 €)
  const { data: inv052 } = await supabase.from('invoices').select('id, currency, total_cents').eq('number', '052').maybeSingle();
  if (inv052) {
    const { data: pay052 } = await supabase.from('invoice_payments').select('id').eq('invoice_id', inv052.id);
    if (!pay052?.length) {
      await supabase.from('invoice_payments').insert({
        organization_id: orgId,
        created_by: dummyUserId,
        invoice_id: inv052.id,
        amount_cents: inv052.total_cents,
        currency: inv052.currency || 'EUR',
        payment_date: '2026-09-16',
        method: 'Transferencia bancaria',
        reference: 'Cobro verificado',
        note: 'Factura cobrada confirmada'
      });
    }
    await supabase.from('invoices').update({ status: 'paid' }).eq('id', inv052.id);
  }

  // 053 - Simran Kaur Chahal (800,00 €)
  const { data: inv053 } = await supabase.from('invoices').select('id, currency, total_cents').eq('number', '053').maybeSingle();
  if (inv053) {
    const { data: pay053 } = await supabase.from('invoice_payments').select('id').eq('invoice_id', inv053.id);
    if (!pay053?.length) {
      await supabase.from('invoice_payments').insert({
        organization_id: orgId,
        created_by: dummyUserId,
        invoice_id: inv053.id,
        amount_cents: inv053.total_cents,
        currency: inv053.currency || 'EUR',
        payment_date: '2026-09-11',
        method: 'Transferencia bancaria',
        reference: 'Anticipo 50%',
        note: 'Cobro de anticipo verificado'
      });
    }
    await supabase.from('invoices').update({ status: 'paid' }).eq('id', inv053.id);
  }

  // Facturas 029 + 047 (Arte Volante): Asignar cobros para dejar exactamente 300,00 € pendientes entre ambas
  const { data: inv029 } = await supabase.from('invoices').select('id, total_cents, notes').eq('number', '029').maybeSingle();
  if (inv029) {
    const { data: pay029 } = await supabase.from('invoice_payments').select('id').eq('invoice_id', inv029.id);
    if (!pay029?.length) {
      await supabase.from('invoice_payments').insert({
        organization_id: orgId,
        created_by: dummyUserId,
        invoice_id: inv029.id,
        amount_cents: 25440,
        currency: 'EUR',
        payment_date: '2026-09-01',
        method: 'Ajuste global',
        reference: 'Arte Volante 029+047',
        note: 'Asignación para dejar 300 € pendientes globales entre 029 y 047'
      });
    }
    await supabase.from('invoices').update({
      notes: (inv029.notes || '') + ' [REVISIÓN: Pendiente global conjunto de 300,00 € entre facturas 029 y 047 (Arte Volante)]'
    }).eq('id', inv029.id);
  }

  const { data: inv047 } = await supabase.from('invoices').select('id, total_cents, notes').eq('number', '047').maybeSingle();
  if (inv047) {
    const { data: pay047 } = await supabase.from('invoice_payments').select('id').eq('invoice_id', inv047.id);
    if (!pay047?.length) {
      await supabase.from('invoice_payments').insert({
        organization_id: orgId,
        created_by: dummyUserId,
        invoice_id: inv047.id,
        amount_cents: 29360,
        currency: 'EUR',
        payment_date: '2026-09-01',
        method: 'Ajuste global',
        reference: 'Arte Volante 029+047',
        note: 'Pago parcial asignado de 293,60 €, dejando exactamente 300,00 € pendientes'
      });
    }
    await supabase.from('invoices').update({
      notes: (inv047.notes || '') + ' [REVISIÓN: Pendiente global conjunto de 300,00 € entre facturas 029 y 047 (Arte Volante)]'
    }).eq('id', inv047.id);
  }

  // 4. Corrección de Eventos a 0 € / null basándonos en facturas PDF
  console.log('\n[EVENTOS] Corrigiendo valores operativos de eventos a partir de facturas...');

  const eventCorrections = [
    { match: 'Sa Torre', date: '2026-07-16', netValue: 24000, invoice: '020', reason: 'Boda Sa Torre 11/07 confirmada en Factura 020' },
    { match: 'Sa Torre', date: '2026-09-10', netValue: 24000, invoice: '020', reason: 'Evento Sa Torre confirmado en Factura 020' },
    { match: 'OBEACH', netValue: 88000, invoice: '026', reason: '5 días O Beach x 880 € netos confirmados en Factura 026' },
    { match: 'O Beach', netValue: 88000, invoice: '041', reason: '3 días O Beach agosto x 880 € netos confirmados en Factura 041' },
    { match: 'UNVRS', netValue: 75000, invoice: '025', reason: '4 días UNVRS x 750 € netos confirmados en Factura 025' },
    { match: 'Flower Power', netValue: 100000, invoice: '027/037', reason: 'Flower Power Pacha 1.000 € netos por fecha confirmados en Facturas 027 y 037' },
    { match: 'Paradise', netValue: 23000, invoice: '032/048', reason: 'Paradise Ushuaïa 230 € netos por fecha confirmados en Facturas 032 y 048' }
  ];

  const { data: allEvents } = await supabase.from('events').select('id, event_name, event_date, income_cents');

  for (const ev of allEvents || []) {
    for (const corr of eventCorrections) {
      if (ev.event_name.toUpperCase().includes(corr.match.toUpperCase()) || (corr.date && ev.event_date === corr.date)) {
        if (!ev.income_cents || ev.income_cents === 0) {
          console.log(`[EVENTO] Corrigiendo "${ev.event_name}" (${ev.event_date}): ${ev.income_cents || 0} € -> ${corr.netValue / 100} €`);
          await supabase.from('events').update({ income_cents: corr.netValue }).eq('id', ev.id);
          
          await supabase.from('financial_audit_log').insert({
            organization_id: orgId,
            entity_type: 'event',
            entity_id: ev.id,
            field_name: 'income_cents',
            old_value: String(ev.income_cents || 0),
            new_value: String(corr.netValue),
            source_invoice_number: corr.invoice,
            reason: corr.reason
          });
        }
      }
    }
  }

  // 5. Creación de Eventos Faltantes Demostrados por Facturas (Simran, Cream Events, Hawksley, Dobson)
  const missingEvents = [
    { name: 'Simran Kaur Chahal Event', date: '2027-05-23', income_cents: 160000, client: 'Simran Kaur Chahal', invoice: '053' },
    { name: 'Cream Events Percusionista Atzaró', date: '2026-10-01', income_cents: 90000, client: 'Cream Events SL', invoice: '056' },
    { name: 'Christopher Hawksley Performances Villa', date: '2026-09-05', income_cents: 120000, client: 'CHRISTOPHER HAWKSLEY', invoice: '057' },
    { name: 'Charley Dobson Na Xamena', date: '2026-10-10', income_cents: 30000, client: 'Charley Dobson', invoice: '055' }
  ];

  for (const me of missingEvents) {
    const { data: evExists } = await supabase.from('events').select('id').ilike('event_name', `%${me.client.split(' ')[0]}%`).maybeSingle();
    if (!evExists) {
      console.log(`[EVENTO FALTANTE] Creando evento para ${me.client} (${me.date}): ${me.income_cents / 100} € netos`);
      const cId = getClientId(me.client);
      await supabase.from('events').insert({
        organization_id: orgId,
        event_code: `EV-${me.invoice}`,
        event_name: me.name,
        client_id: cId,
        event_date: me.date,
        income_cents: me.income_cents,
        country: 'España',
        status: 'confirmed',
        health: 'good',
        board_position: 100
      });
    }
  }

  console.log('\n=== AUDITORÍA Y ACTUALIZACIÓN COMPLETADA CON ÉXITO ===');
}

main().catch(err => {
  console.error('Fatal error in audit execution:', err);
  process.exit(1);
});
