import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

async function audit() {
  const targetNumbers = [
    '018', '019', '025', '029', '032', '035', '037', '038', '041', '043',
    '044', '046', '047', '048', '049', '052', '053', '054', '055', '056', '057', '058'
  ];

  const { data: invoices, error: invErr } = await supabase
    .from('invoices')
    .select('*, client:clients(company_name)')
    .order('number');

  if (invErr) {
    console.error('Error fetching invoices:', invErr);
    return;
  }

  const { data: payments, error: payErr } = await supabase
    .from('invoice_payments')
    .select('*');

  if (payErr) {
    console.error('Error fetching payments:', payErr);
    return;
  }

  console.log(`Found ${invoices.length} total invoices in DB.\n`);

  for (const num of targetNumbers) {
    const invList = invoices.filter(i => i.number === num || i.number.padStart(3, '0') === num);
    console.log(`=== FACTURA ${num} ===`);
    if (!invList.length) {
      console.log(`  NOT FOUND IN DB!`);
      continue;
    }
    for (const inv of invList) {
      const invPayments = payments.filter(p => p.invoice_id === inv.id);
      const receivedCents = invPayments.reduce((s, p) => s + Number(p.amount_cents), 0);
      const pendingCents = Number(inv.total_cents) - receivedCents;
      console.log(`  ID: ${inv.id}`);
      console.log(`  Number: "${inv.number}"`);
      console.log(`  Client DB: "${inv.client?.company_name || 'NO CLIENT'}"`);
      console.log(`  Concept: "${inv.concept}"`);
      console.log(`  Status DB: "${inv.status}"`);
      console.log(`  Total: ${(inv.total_cents / 100).toFixed(2)} € (${inv.total_cents} cents)`);
      console.log(`  Received DB: ${(receivedCents / 100).toFixed(2)} € (${receivedCents} cents)`);
      console.log(`  Pending DB: ${(pendingCents / 100).toFixed(2)} € (${pendingCents} cents)`);
      console.log(`  Payments count: ${invPayments.length}`);
      if (invPayments.length) {
        invPayments.forEach(p => console.log(`    - Payment: ${(p.amount_cents / 100).toFixed(2)} € on ${p.payment_date} (${p.note})`));
      }
      console.log(`  Notes DB: "${inv.notes || ''}"`);
    }
    console.log('');
  }
}

audit();
