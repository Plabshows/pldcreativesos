-- SQL Script: Q3 2026 Financial Audit & Economic Reality Sync
-- Organization ID: 191c90ad-5337-405e-9d1a-abae2ad8c70e

BEGIN;

-- 1. Ensure invoice status check constraint allows 'unverified' and 'paid'
ALTER TABLE public.invoices DROP CONSTRAINT IF EXISTS invoices_status_check;
ALTER TABLE public.invoices ADD CONSTRAINT invoices_status_check CHECK (status IN ('draft', 'sent', 'pending', 'unverified', 'paid', 'cancelled'));

-- 2. Upsert required client records with client_code
INSERT INTO public.clients (id, organization_id, client_code, company_name, created_at, updated_at)
VALUES 
  ('a1111111-0000-4000-a000-000000000001', '191c90ad-5337-405e-9d1a-abae2ad8c70e', 'CLI-DOBSON', 'Charley Dobson', NOW(), NOW()),
  ('a1111111-0000-4000-a000-000000000002', '191c90ad-5337-405e-9d1a-abae2ad8c70e', 'CLI-CREAM', 'Cream Events', NOW(), NOW()),
  ('a1111111-0000-4000-a000-000000000003', '191c90ad-5337-405e-9d1a-abae2ad8c70e', 'CLI-SIMRAN', 'Simran Kaur Chahal', NOW(), NOW()),
  ('a1111111-0000-4000-a000-000000000004', '191c90ad-5337-405e-9d1a-abae2ad8c70e', 'CLI-SATORRE', 'Sa Torre Ibiza', NOW(), NOW())
ON CONFLICT (id) DO UPDATE SET company_name = EXCLUDED.company_name, client_code = EXCLUDED.client_code;

-- Get default admin user ID for invoice creation
DO $$ 
DECLARE 
  admin_uid UUID;
  org_uid UUID := '191c90ad-5337-405e-9d1a-abae2ad8c70e';
  client_dobson UUID;
  client_cream UUID;
  client_simran UUID;
  client_satorre UUID;
  client_arte UUID;
  client_nassau UUID;
  client_ushuaia UUID;
  client_pacha UUID;
  client_obeach UUID;
BEGIN
  SELECT id INTO admin_uid FROM public.users LIMIT 1;
  SELECT id INTO client_arte FROM public.clients WHERE organization_id = org_uid AND company_name ILIKE '%ARTE VOLANTE%' LIMIT 1;
  SELECT id INTO client_nassau FROM public.clients WHERE organization_id = org_uid AND company_name ILIKE '%NASSAU%' LIMIT 1;
  SELECT id INTO client_ushuaia FROM public.clients WHERE organization_id = org_uid AND (company_name ILIKE '%USHUAIA%' OR company_name ILIKE '%UNVRS%') LIMIT 1;
  IF client_ushuaia IS NULL THEN
    SELECT id INTO client_ushuaia FROM public.clients WHERE organization_id = org_uid LIMIT 1;
  END IF;
  SELECT id INTO client_pacha FROM public.clients WHERE organization_id = org_uid AND company_name ILIKE '%PACHA%' LIMIT 1;
  IF client_pacha IS NULL THEN
    SELECT id INTO client_pacha FROM public.clients WHERE organization_id = org_uid LIMIT 1;
  END IF;
  SELECT id INTO client_obeach FROM public.clients WHERE organization_id = org_uid AND (company_name ILIKE '%O BEACH%' OR company_name ILIKE '%ICE MOUNTAIN%') LIMIT 1;
  IF client_obeach IS NULL THEN
    SELECT id INTO client_obeach FROM public.clients WHERE organization_id = org_uid LIMIT 1;
  END IF;

  client_dobson := 'a1111111-0000-4000-a000-000000000001';
  client_cream := 'a1111111-0000-4000-a000-000000000002';
  client_simran := 'a1111111-0000-4000-a000-000000000003';
  client_satorre := 'a1111111-0000-4000-a000-000000000004';

  -- Factura 017 (High Frequency / Nassau) -> 8.143,63 € (814363 cents) Pending
  UPDATE public.invoices SET total_cents = 814363, base_cents = 673027, tax_cents = 141336, status = 'pending', concept = 'High Frequency / Nassau Events', notes = 'Pendiente verificado 8.143,63 €' WHERE organization_id = org_uid AND number = '017';

  -- Factura 018 (Cream Events / Amnesia Pyramid) -> 1.086,50 € (108650 cents) Unverified
  UPDATE public.invoices SET status = 'unverified', notes = 'Cobro por verificar (1.086,50 €)' WHERE organization_id = org_uid AND number = '018';

  -- Factura 019 (Fundación Pacha) -> 106,00 € (10600 cents) Unverified
  UPDATE public.invoices SET status = 'unverified', notes = 'Cobro por verificar (106,00 €)' WHERE organization_id = org_uid AND number = '019';

  -- Factura 025 (Ushuaia / UNVRS) -> 3.180,00 € (318000 cents) Pending
  UPDATE public.invoices SET status = 'pending', total_cents = 318000, notes = 'Pendiente verificado 3.180,00 €' WHERE organization_id = org_uid AND number = '025';

  -- Factura 028 (Arte Volante / Movida 80s Sa Nostra) -> 1.537,00 € (153700 cents) Pending
  UPDATE public.invoices SET total_cents = 153700, base_cents = 127025, tax_cents = 26675, status = 'pending', notes = 'Pendiente verificado 1.537,00 €' WHERE organization_id = org_uid AND number = '028';

  -- Facturas 029 + 047 (Arte Volante) -> 300,00 € total remaining pending between both
  UPDATE public.invoices SET total_cents = 30000, status = 'pending', notes = 'Facturas 029 + 047: quedan 300,00 € pendientes en total entre ambas' WHERE organization_id = org_uid AND number = '029';
  UPDATE public.invoices SET total_cents = 59360, status = 'paid', notes = 'Cobrada / Asignada dentro del paquete 029+047' WHERE organization_id = org_uid AND number = '047';

  -- Factura 030 (Fundación Pacha) -> 159,00 € (15900 cents) Pending
  UPDATE public.invoices SET status = 'pending', total_cents = 15900, notes = 'Pendiente verificado 159,00 €' WHERE organization_id = org_uid AND number = '030';

  -- Factura 032 (Ushuaia) -> 583,00 € (58300 cents) Pending
  UPDATE public.invoices SET status = 'pending', total_cents = 58300, notes = 'Pendiente verificado 583,00 €' WHERE organization_id = org_uid AND number = '032';

  -- Factura 035 (Fundación Pacha) -> 530,00 € (53000 cents) Pending
  UPDATE public.invoices SET status = 'pending', total_cents = 53000, notes = 'Pendiente verificado 530,00 €' WHERE organization_id = org_uid AND number = '035';

  -- Factura 037 (Fundación Pacha — Flower Power) -> 5.300,00 € Paid
  UPDATE public.invoices SET status = 'paid', notes = 'Cobrada 5.300,00 € (Verificado en banco)' WHERE organization_id = org_uid AND number = '037';

  -- Factura 038 (Arte Volante / Rememberland) -> 2.777,20 € (277720 cents) Unverified
  UPDATE public.invoices SET status = 'unverified', notes = 'Cobro por verificar (2.777,20 €)' WHERE organization_id = org_uid AND number = '038';

  -- Factura 041 (Ice Mountain / O Beach) -> 2.798,40 € (279840 cents) Pending
  UPDATE public.invoices SET status = 'pending', total_cents = 279840, notes = 'Pendiente verificado 2.798,40 €' WHERE organization_id = org_uid AND number = '041';

  -- Factura 044 (Arte Volante / Another Dimension) -> 731,40 € (73140 cents) Pending
  UPDATE public.invoices SET total_cents = 73140, base_cents = 60446, tax_cents = 12694, status = 'pending', notes = 'Pendiente verificado 731,40 €' WHERE organization_id = org_uid AND number = '044';

  -- Factura 049 (High Frequency / Nassau) -> 1.160,84 € (116084 cents) Unverified
  UPDATE public.invoices SET total_cents = 116084, status = 'unverified', notes = 'Cobro por verificar (1.160,84 €)' WHERE organization_id = org_uid AND number = '049';

  -- Factura 052 (Ushuaia / UNVRS) -> 1.929,20 € Paid
  UPDATE public.invoices SET status = 'paid', notes = 'Cobrada 1.929,20 € (Verificado en banco)' WHERE organization_id = org_uid AND number = '052';

  -- Insert Factura 053 (Charley Dobson) -> 260,00 € Paid
  INSERT INTO public.invoices (organization_id, client_id, number, issue_date, due_date, concept, base_cents, tax_cents, total_cents, currency, status, notes, created_by)
  VALUES (org_uid, client_dobson, '053', '2026-09-08', '2026-09-08', 'Servicios de actuación / Performance Charley Dobson', 26000, 0, 26000, 'EUR', 'paid', 'Charley Dobson — 260,00 € (Cobrada)', admin_uid)
  ON CONFLICT (organization_id, number) DO UPDATE SET status = 'paid', total_cents = 26000, notes = EXCLUDED.notes;

  -- Insert Factura 054 (Cream Events) -> 2.226,00 € Pending
  INSERT INTO public.invoices (organization_id, client_id, number, issue_date, due_date, concept, base_cents, tax_cents, total_cents, currency, status, notes, created_by)
  VALUES (org_uid, client_cream, '054', '2026-09-09', '2026-10-09', 'Cream Events — Espectáculos Amnesia Pyramid', 183967, 38633, 222600, 'EUR', 'pending', 'Cream Events — 2.226,00 € pendientes', admin_uid)
  ON CONFLICT (organization_id, number) DO UPDATE SET status = 'pending', total_cents = 222600, notes = EXCLUDED.notes;

  -- Insert Factura 055 (Simran Kaur Chahal) -> 300,00 € Pending
  INSERT INTO public.invoices (organization_id, client_id, number, issue_date, due_date, concept, base_cents, tax_cents, total_cents, currency, status, notes, created_by)
  VALUES (org_uid, client_simran, '055', '2026-09-10', '2026-10-10', 'Simran Kaur Chahal — Show privado', 24793, 5207, 30000, 'EUR', 'pending', 'Simran Kaur Chahal — 300,00 € pendientes', admin_uid)
  ON CONFLICT (organization_id, number) DO UPDATE SET status = 'pending', total_cents = 30000, notes = EXCLUDED.notes;

  -- Insert Factura 056 (Sa Torre Ibiza) -> 477,00 € Unverified
  INSERT INTO public.invoices (organization_id, client_id, number, issue_date, due_date, concept, base_cents, tax_cents, total_cents, currency, status, notes, created_by)
  VALUES (org_uid, client_satorre, '056', '2026-09-11', '2026-10-11', 'Sa Torre Ibiza — Actuaciones privadas', 39421, 8279, 47700, 'EUR', 'unverified', 'Sa Torre Ibiza — 477,00 € por verificar (Cobro por verificar)', admin_uid)
  ON CONFLICT (organization_id, number) DO UPDATE SET status = 'unverified', total_cents = 47700, notes = EXCLUDED.notes;

  -- Insert Factura 057 (Arte Volante) -> 1.200,00 € Unverified
  INSERT INTO public.invoices (organization_id, client_id, number, issue_date, due_date, concept, base_cents, tax_cents, total_cents, currency, status, notes, created_by)
  VALUES (org_uid, client_arte, '057', '2026-09-12', '2026-10-12', 'Arte Volante SL — Producción artística', 99174, 20826, 120000, 'EUR', 'unverified', 'Arte Volante — 1.200,00 € por verificar (Cobro por verificar)', admin_uid)
  ON CONFLICT (organization_id, number) DO UPDATE SET status = 'unverified', total_cents = 120000, notes = EXCLUDED.notes;

  -- Insert Factura 058 (Arte Volante) -> 1.378,00 € Pending
  INSERT INTO public.invoices (organization_id, client_id, number, issue_date, due_date, concept, base_cents, tax_cents, total_cents, currency, status, notes, created_by)
  VALUES (org_uid, client_arte, '058', '2026-09-13', '2026-10-13', 'Arte Volante SL — Eventos y Shows', 113884, 23916, 137800, 'EUR', 'pending', 'Arte Volante — 1.378,00 € pendientes', admin_uid)
  ON CONFLICT (organization_id, number) DO UPDATE SET status = 'pending', total_cents = 137800, notes = EXCLUDED.notes;

END $$;

-- 3. Audit Logging
INSERT INTO public.financial_audit_log (organization_id, entity_type, entity_id, field_name, old_value, new_value, source_invoice_number, reason)
SELECT organization_id, 'invoice', id, 'status', 'various', status, number, 'Q3 2026 Financial Audit & System Reality Synchronization'
FROM public.invoices
WHERE organization_id = '191c90ad-5337-405e-9d1a-abae2ad8c70e' AND number IN ('017','018','019','025','028','029','030','032','035','037','038','041','044','047','049','052','053','054','055','056','057','058');

COMMIT;
