import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const envFile = fs.readFileSync(path.resolve(__dirname, '../.env.local'), 'utf-8');
const env = Object.fromEntries(envFile.split('\n').filter(l => l && !l.startsWith('#')).map(l => l.split('=')));

const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data: et, error: err1 } = await supabase.from('event_talent').select('*').not('agreed_cost_cents', 'is', null).order('created_at', { ascending: false }).limit(5);
  console.log("event_talent with fee:", et, err1);
  const { data: pays, error: err2 } = await supabase.from('payments').select('*').order('created_at', { ascending: false }).limit(5);
  console.log("payments:", pays, err2);
}
main();
