import { createClient } from '@supabase/supabase-js';
import fs from 'fs';

const envFile = fs.readFileSync('.env.local', 'utf8');
const env = Object.fromEntries(envFile.split('\n').filter(l => l && !l.startsWith('#')).map(l => {
  const i = l.indexOf('=');
  return [l.substring(0, i), l.substring(i+1).replace(/^"|"$/g, '')];
}));

const supabase = createClient(
  env.NEXT_PUBLIC_SUPABASE_URL,
  env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
);

async function run() {
  const orgRes = await supabase.from('organizations').select('*').limit(1).single();
  const orgId = orgRes.data.id;
  
  const { data: clients } = await supabase.from('clients')
    .select('*')
    .eq('organization_id', orgId)
    .or('company_name.ilike.%nacho%,company_name.ilike.%savana%,company_name.ilike.%akuarela%,contact_name.ilike.%nacho%');
  
  console.log('CLIENTS:', JSON.stringify(clients, null, 2));

  const { data: events } = await supabase.from('events')
    .select('id, event_name, event_date, venue, city, client_id, income_cents, internal_notes, event_talent(talent_id, agreed_cost_cents, talent(real_name))')
    .eq('organization_id', orgId)
    .gte('event_date', '2026-08-01')
    .lte('event_date', '2026-09-30');
    
  console.log('\nAUGUST/SEPT EVENTS:', JSON.stringify(events.filter(e => 
    e.venue?.toLowerCase().includes('akuarela') || 
    e.venue?.toLowerCase().includes('savana') ||
    clients?.some(c => c.id === e.client_id) ||
    e.event_name?.toLowerCase().includes('nacho') ||
    e.event_name?.toLowerCase().includes('savana') ||
    e.event_name?.toLowerCase().includes('akuarela')
  ), null, 2));
}
run();
