import { createClient } from '@supabase/supabase-js';
const supabase = createClient(
  'https://jggoimqcrpqarhaojrva.supabase.co',
  'sb_publishable_UiokJaNNQXyf06Mpwn1RNg_qoT5aWJL'
);

async function run() {
  const { data: clients } = await supabase.from('clients')
    .select('id, company_name, contact_name')
    .or('company_name.ilike.%nacho%,company_name.ilike.%savana%,company_name.ilike.%akuarela%,contact_name.ilike.%nacho%');
  
  console.log('CLIENTS:', JSON.stringify(clients, null, 2));

  const { data: events } = await supabase.from('events')
    .select('id, event_name, event_date, venue, city, client_id, income_cents, internal_notes')
    .gte('event_date', '2026-08-01')
    .lte('event_date', '2026-09-30');
    
  console.log('\nAUGUST/SEPT EVENTS:', JSON.stringify(events?.filter(e => 
    e.venue?.toLowerCase().includes('akuarela') || 
    e.venue?.toLowerCase().includes('savana') ||
    clients?.some(c => c.id === e.client_id) ||
    e.event_name?.toLowerCase().includes('nacho') ||
    e.event_name?.toLowerCase().includes('savana') ||
    e.event_name?.toLowerCase().includes('akuarela')
  ), null, 2));

  const { data: talent } = await supabase.from('talent').select('id, real_name');
  console.log('\nTOTAL TALENT:', talent?.length);
}
run();
