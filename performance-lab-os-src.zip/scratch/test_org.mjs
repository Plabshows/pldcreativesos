import { createClient } from '@supabase/supabase-js';
import fs from 'fs';

const envFile = fs.readFileSync('.env.local', 'utf8');
const env = Object.fromEntries(envFile.split('\n').filter(l => l && !l.startsWith('#')).map(l => {
  const i = l.indexOf('=');
  return [l.substring(0, i), l.substring(i+1).replace(/^"|"$/g, '').trim()];
}));

const supabase = createClient(
  env.NEXT_PUBLIC_SUPABASE_URL,
  env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
);

async function run() {
  const orgRes = await supabase.from('organizations').select('*').limit(1).single();
  console.log('Org res:', orgRes);
  if (!orgRes.data) return;
  const orgId = orgRes.data.id;
  console.log('Org ID:', orgId);

  const { data: clients } = await supabase.from('clients').select('*').eq('organization_id', orgId);
  console.log('Clients count:', clients?.length);
  (clients || []).forEach(c => console.log(`Client: ${c.company_name} | Legal: ${c.company || c.legal_name} | Tax: ${c.tax_id}`));

  const { data: invoices } = await supabase.from('invoices').select('*').eq('organization_id', orgId);
  console.log('\nInvoices count:', invoices?.length);
  (invoices || []).forEach(i => console.log(`Invoice ${i.number}: Total ${i.total_cents} | Status ${i.status} | Client: ${i.client_id}`));

  const { data: payments } = await supabase.from('invoice_payments').select('*').eq('organization_id', orgId);
  console.log('\nInvoice payments count:', payments?.length);
  (payments || []).forEach(p => console.log(`Payment: Inv ${p.invoice_id} | Date ${p.payment_date} | Amt ${p.amount_cents}`));

  const { data: events } = await supabase.from('events').select('*').eq('organization_id', orgId).is('deleted_at', null);
  console.log('\nEvents count:', events?.length);
  (events || []).filter(e => /ice|obeach/i.test(e.event_name || '') || /ice|obeach/i.test(e.venue || '')).forEach(e => {
    console.log(`Event: ${e.id} | Date: ${e.event_date} | Name: ${e.event_name} | Client: ${e.client_id} | Inv: ${e.invoice_number} | Paid: ${e.client_paid}`);
  });
}

run().catch(console.error);
