import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../.env.local') });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function main() {
  const { data: et, error } = await supabase.from('event_talent').update({
    agreed_cost_cents: 25000,
    status: 'pending'
  }).eq('organization_id', 'ce74db96-1c09-4ffc-99f5-19e9f1a26090') // I need the org ID
  console.log("update result:", et, error);
}
main();
