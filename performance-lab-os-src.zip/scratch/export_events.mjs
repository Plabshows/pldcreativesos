import { execSync } from 'child_process';
import * as XLSX from 'xlsx';
import path from 'path';

function runQuery(sql) {
  const cmd = `npx supabase db query --linked "${sql.replace(/"/g, '\\"')}"`;
  const out = execSync(cmd, { encoding: 'utf-8', cwd: process.cwd() });
  const match = out.match(/\{[\s\S]*"rows"[\s\S]*\}/);
  if (!match) return [];
  const parsed = JSON.parse(match[0]);
  return parsed.rows || [];
}

async function exportEvents() {
  console.log('Fetching all events data via linked Supabase query...');

  const sql = `
  SELECT 
    e.id,
    e.event_code,
    e.event_date,
    e.event_name,
    c.company_name as client_name,
    e.venue,
    e.city,
    e.status,
    e.wardrobe_notes,
    e.internal_notes,
    e.requested_entertainment,
    COALESCE(e.income_cents, 0) as income_cents,
    COALESCE(e.expenses_cents, 0) as expenses_cents,
    COALESCE(e.other_expenses_cents, 0) as other_expenses_cents,
    e.client_paid,
    e.invoice_number,
    e.billing_type,
    (
      SELECT STRING_AGG(s.name, ', ')
      FROM public.event_shows es
      JOIN public.shows s ON s.id = es.show_id
      WHERE es.event_id = e.id
    ) as shows_list,
    (
      SELECT STRING_AGG(COALESCE(t.stage_name, t.real_name), ', ')
      FROM public.event_talent et
      JOIN public.talent t ON t.id = et.talent_id
      WHERE et.event_id = e.id
    ) as talent_list
  FROM public.events e
  LEFT JOIN public.clients c ON c.id = e.client_id
  ORDER BY e.event_date ASC;
  `;

  const events = runQuery(sql);
  console.log(`Found ${events.length} events in database.`);

  const daysOfWeekEs = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

  const formattedRows = events.map(e => {
    let dayOfWeek = '';
    if (e.event_date) {
      const d = new Date(e.event_date);
      dayOfWeek = daysOfWeekEs[d.getUTCDay()];
    }

    let shows = e.shows_list || e.requested_entertainment || '—';
    
    let talent = e.talent_list;
    if (!talent) {
      if (e.internal_notes && e.internal_notes.includes('[Sin artistas o alquiler]')) {
        talent = '🚫 Sin artistas / Alquiler';
      } else {
        talent = 'Sin artistas asignados';
      }
    }

    const income = Number(e.income_cents) / 100;
    const expenses = Number(e.expenses_cents) / 100;
    const otherExpenses = Number(e.other_expenses_cents) / 100;
    const profit = income - expenses - otherExpenses;

    return {
      'Ref / Código': e.event_code || (e.id ? e.id.substring(0, 8) : ''),
      'Fecha': e.event_date || '',
      'Día': dayOfWeek,
      'Nombre / Detalle Evento': e.event_name || 'Evento',
      'Cliente': e.client_name || 'Sin cliente',
      'Localización / Venue': e.venue || '—',
      'Ciudad': e.city || '—',
      'Shows Vinculados': shows,
      'Artistas y Proveedores': talent,
      'Vestuario': e.wardrobe_notes || '—',
      'Ingreso Total (€)': income,
      'Gastos Sueldos (€)': expenses,
      'Otros Gastos (€)': otherExpenses,
      'Beneficio Estimado (€)': profit,
      'Estado Cobro': e.client_paid ? 'Pagado' : 'Pendiente',
      'Nº Factura': e.invoice_number || '—',
      'Tipo Facturación': e.billing_type || '—',
      'Estado Producción': e.status || 'production',
      'Notas Internas': e.internal_notes || ''
    };
  });

  // Create Worksheet
  const worksheet = XLSX.utils.json_to_sheet(formattedRows);

  // Set column widths
  worksheet['!cols'] = [
    { wch: 14 }, // Ref
    { wch: 12 }, // Fecha
    { wch: 10 }, // Día
    { wch: 35 }, // Nombre
    { wch: 30 }, // Cliente
    { wch: 20 }, // Venue
    { wch: 12 }, // Ciudad
    { wch: 30 }, // Shows
    { wch: 32 }, // Artistas
    { wch: 18 }, // Vestuario
    { wch: 16 }, // Ingreso
    { wch: 18 }, // Gastos Sueldos
    { wch: 16 }, // Otros Gastos
    { wch: 20 }, // Beneficio
    { wch: 14 }, // Estado Cobro
    { wch: 14 }, // Nº Factura
    { wch: 16 }, // Tipo Facturación
    { wch: 18 }, // Estado Producción
    { wch: 45 }  // Notas
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Eventos Performance Lab');

  const rootPath = path.join(process.cwd(), 'eventos_performance_lab_os.xlsx');
  const publicPath = path.join(process.cwd(), 'public', 'eventos_performance_lab_os.xlsx');

  XLSX.writeFile(workbook, rootPath);
  XLSX.writeFile(workbook, publicPath);

  console.log(`Excel file created successfully with ${events.length} events!`);
  console.log(`Saved to: ${rootPath}`);
  console.log(`Saved to: ${publicPath}`);
}

exportEvents().catch(console.error);
