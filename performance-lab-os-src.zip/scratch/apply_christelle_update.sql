-- =================================================================
-- CLIENT & EVENTS UPDATE - CHRISTELLE STEPHANIE BAROUSSE (MALLORCA)
-- =================================================================

BEGIN;

-- 1. UNIFY & COMPLETE CLIENT RECORD
UPDATE public.clients
SET 
  company_name = 'Christelle Stephanie Barousse',
  company = 'CHRISTELLE STEPHANIE BAROUSE',
  tax_id = 'X3117792G',
  billing_address = 'Carreró D’en Figa 9, Escalera B, Planta 1, Apto 4A',
  postal_code = '07800',
  city = 'Sóller',
  province = 'Illes Balears',
  country = 'España',
  client_type = 'Cliente',
  notes = COALESCE(notes, '') || E'\n--- 16/09/2026 ---\nMercado / Ubicación: Mallorca. Cliente unificada de eventos 2026 (5 eventos en Mallorca).',
  updated_at = NOW()
WHERE id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8';

-- Re-link any events or invoices pointing to the secondary client card (47e82c6b-0202-4747-bc3f-f171aa741de8)
UPDATE public.events 
SET client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8'
WHERE client_id = '47e82c6b-0202-4747-bc3f-f171aa741de8';

UPDATE public.invoices 
SET client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8'
WHERE client_id = '47e82c6b-0202-4747-bc3f-f171aa741de8';

-- Mark secondary duplicate client card as deleted
UPDATE public.clients
SET deleted_at = NOW()
WHERE id = '47e82c6b-0202-4747-bc3f-f171aa741de8';


-- 2. CONFIRM PAYMENT & UPDATE FACTURA 020
UPDATE public.invoices
SET
  client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8',
  status = 'pending',
  notes = 'Factura 020 COBRADA el 16/07/2026 via Transferencia bancaria (254,40 €). Ordenante: Christelle Stephanie Barousse. Concepto: Pago Fra 20.',
  updated_at = NOW()
WHERE id = 'ab475784-394a-47eb-9c00-146c9cae0ed7';

-- Update or insert payment for Factura 020
UPDATE public.invoice_payments
SET
  payment_date = '2026-07-16',
  amount_cents = 25440,
  method = 'Transferencia bancaria',
  reference = 'Pago Fra 20',
  note = 'Pago verificado por transferencia bancaria de Christelle Stephanie Barousse el 16/07/2026 (Pago Fra 20)',
  created_by = 'afaa92ff-b00c-4fcf-9d1b-3155d18e370e'
WHERE invoice_id = 'ab475784-394a-47eb-9c00-146c9cae0ed7';


-- 3. UPDATE / CREATE 5 MALLORCA 2026 EVENTS

-- Event 1: 11/07/2026 — Mallorca (Update existing event bca6e371-137c-4099-b426-536102b6d4de)
UPDATE public.events
SET
  client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8',
  event_name = 'Christelle · Mallorca · 2 DB',
  venue = 'Mallorca',
  city = 'Mallorca',
  invoice_number = '020',
  client_paid = true,
  status = 'completed',
  internal_notes = 'Servicio contratado: 2 DB. Factura 20 (254,40 €) cobrada el 16/07/2026.',
  updated_at = NOW()
WHERE id = 'bca6e371-137c-4099-b426-536102b6d4de';


-- Event 2: 16/07/2026 — Mallorca (2 DB, Pagado)
INSERT INTO public.events (
  organization_id, client_id, event_code, event_name, event_date, venue, city, client_paid, status, income_cents, internal_notes
) VALUES (
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  '9cb2684e-d804-4a7e-b4af-2f93e32730a8',
  'EV-CHRISTELLE-20260716',
  'Christelle · Mallorca · 2 DB',
  '2026-07-16',
  'Mallorca',
  'Mallorca',
  true,
  'completed',
  NULL,
  'Servicio contratado: 2 DB. Estado de pago: PAGADO ✅.'
) ON CONFLICT DO NOTHING;


-- Event 3: 10/09/2026 — Mallorca (2 DB, Pendiente)
INSERT INTO public.events (
  organization_id, client_id, event_code, event_name, event_date, venue, city, client_paid, status, income_cents, internal_notes
) VALUES (
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  '9cb2684e-d804-4a7e-b4af-2f93e32730a8',
  'EV-CHRISTELLE-20260910',
  'Christelle · Mallorca · 2 DB',
  '2026-09-10',
  'Mallorca',
  'Mallorca',
  false,
  'completed',
  NULL,
  'Servicio contratado: 2 DB. Estado de pago: PENDIENTE. Nota: Pago pdte recibir Fra.'
) ON CONFLICT DO NOTHING;


-- Event 4: 20/09/2026 — Mallorca (2 DB, Programado)
INSERT INTO public.events (
  organization_id, client_id, event_code, event_name, event_date, venue, city, client_paid, status, income_cents, internal_notes
) VALUES (
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  '9cb2684e-d804-4a7e-b4af-2f93e32730a8',
  'EV-CHRISTELLE-20260920',
  'Christelle · Mallorca · 2 DB',
  '2026-09-20',
  'Mallorca',
  'Mallorca',
  NULL,
  'confirmed',
  NULL,
  'Servicio contratado: 2 DB. Estado: Confirmado / Programado.'
) ON CONFLICT DO NOTHING;


-- Event 5: 25/09/2026 — Mallorca (2 DB + 2 Mirror Men, Programado)
INSERT INTO public.events (
  organization_id, client_id, event_code, event_name, event_date, venue, city, client_paid, status, income_cents, internal_notes
) VALUES (
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  '9cb2684e-d804-4a7e-b4af-2f93e32730a8',
  'EV-CHRISTELLE-20260925',
  'Christelle · Mallorca · 2 DB + 2 Mirror Men',
  '2026-09-25',
  'Mallorca',
  'Mallorca',
  NULL,
  'confirmed',
  NULL,
  'Servicios contratados: 2 DB, 2 Mirror Men. Estado: Confirmado / Programado.'
) ON CONFLICT DO NOTHING;

COMMIT;
