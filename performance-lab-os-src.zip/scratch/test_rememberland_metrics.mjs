import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import { clientMetrics } from '../lib/client-insights';

const envFile = fs.readFileSync('.env.local', 'utf8');
const env = Object.fromEntries(envFile.split('\n').filter(l => l && !l.startsWith('#')).map(l => {
  const i = l.indexOf('=');
  return [l.substring(0, i), l.substring(i+1).replace(/^"|"$/g, '').trim()];
}));

const supabase = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);

async function run() {
  const orgRes = await supabase.from('organizations').select('*').limit(1).single();
  const orgId = orgRes.data.id;

  const { data: client } = await supabase.from('clients').select('*').eq('organization_id', orgId).ilike('company_name', '%rememberland%').single();
  const { data: events } = await supabase.from('events').select('*').eq('organization_id', orgId).is('deleted_at', null);
  const { data: invoices } = await supabase.from('invoices').select('*').eq('organization_id', orgId);
  const { data: payments } = await supabase.from('invoice_payments').select('*').eq('organization_id', orgId);
  const { data: expenses } = await supabase.from('expenses').select('*').eq('organization_id', orgId);

  const data = {
    clients: [client],
    events: events || [],
    invoices: invoices || [],
    payments: payments || [],
    expenses: expenses || [],
    shows: [],
    showLinks: []
  };

  const m = clientMetrics(client, data, 'EUR');
  console.log('CLIENT METRICS FOR REMEMBERLAND:');
  console.log('jobs:', m.jobs);
  console.log('revenue:', m.revenue);
  console.log('eventsRevenue:', m.eventsRevenue);
  console.log('invoiced:', m.invoiced);
  console.log('paid:', m.paid);
  console.log('pending:', m.pending);
  console.log('reconciliationDiff:', m.reconciliationDiff);
}

run().catch(console.error);
