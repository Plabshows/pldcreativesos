
      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contacto@aotravelagency.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
    
UPDATE public.events SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
UPDATE public.invoices SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
UPDATE public.proposals SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
UPDATE public.client_contacts SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
UPDATE public.tasks SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
UPDATE public.leads SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
UPDATE public.opportunities SET client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c' WHERE client_id = '6721b639-461c-446d-ae0c-849f555a4504';
DELETE FROM public.clients WHERE id = '6721b639-461c-446d-ae0c-849f555a4504';