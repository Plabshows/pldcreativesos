-- =================================================================
-- FINANCIAL UPDATE & BANK RECONCILIATION - 15/09/2026
-- Client: ICE MOUNTAIN S.L. (5b1c5f25-8388-4aa1-9d57-d6e331fca365)
-- =================================================================

BEGIN;

-- 1. UNIFY / UPDATE CLIENT RECORD
UPDATE public.clients
SET 
  company_name = 'ICE MOUNTAIN S.L. (O Beach)',
  company = 'ICE MOUNTAIN S.L.',
  tax_id = 'B57704124',
  city = 'Sant Antoni',
  province = 'Illes Balears',
  country = 'España',
  notes = COALESCE(notes, '') || E'\n--- 15/09/2026 ---\nRazón social unificada: ICE MOUNTAIN S.L. Marcas/Aliases: Ice Mountain Ibiza SL, Ice mountain ibiza s.l, O Beach Ibiza, OBEACH.',
  updated_at = NOW()
WHERE id = '5b1c5f25-8388-4aa1-9d57-d6e331fca365';


-- 2. FACTURA Nº015 — COBRADA (3.052,80 € el 14/08/2026)
UPDATE public.invoices
SET
  status = 'pending',
  client_id = '5b1c5f25-8388-4aa1-9d57-d6e331fca365',
  issue_date = '2026-06-29',
  base_cents = 288000,
  tax_cents = 60480,
  retention_cents = 43200,
  total_cents = 305280,
  notes = 'Factura 015 COBRADA el 14/08/2026 via Transferencia bancaria (BBVA). Total recibido: 3.052,80 €.',
  updated_at = NOW()
WHERE id = 'e015907b-fec8-40a5-a2e4-09d67469dc7a';

-- Update existing payment for invoice 015 to exact banking method & date
UPDATE public.invoice_payments
SET
  payment_date = '2026-08-14',
  amount_cents = 305280,
  method = 'Transferencia bancaria',
  reference = 'Factura 015 · BBVA',
  note = 'Cobro bancario verificado fecha 14/08/2026. Transferencia BBVA',
  created_by = 'afaa92ff-b00c-4fcf-9d1b-3155d18e370e'
WHERE invoice_id = 'e015907b-fec8-40a5-a2e4-09d67469dc7a';

-- If no payment existed for 015, insert one
INSERT INTO public.invoice_payments (
  organization_id, invoice_id, payment_date, amount_cents, currency, method, reference, note, created_by
)
SELECT 
  '191c90ad-5337-405e-9d1a-abae2ad8c70e', 
  'e015907b-fec8-40a5-a2e4-09d67469dc7a', 
  '2026-08-14', 
  305280, 
  'EUR', 
  'Transferencia bancaria', 
  'Factura 015 · BBVA', 
  'Cobro bancario verificado fecha 14/08/2026. Transferencia BBVA',
  'afaa92ff-b00c-4fcf-9d1b-3155d18e370e'
WHERE NOT EXISTS (
  SELECT 1 FROM public.invoice_payments WHERE invoice_id = 'e015907b-fec8-40a5-a2e4-09d67469dc7a'
);

-- Update events tied to Factura 015 as client_paid = true
UPDATE public.events
SET 
  client_id = '5b1c5f25-8388-4aa1-9d57-d6e331fca365',
  invoice_number = '015',
  client_paid = true,
  updated_at = NOW()
WHERE id IN (
  'b887c1b5-5725-432a-90ee-5053f7263270', -- 21/05/2026 Rent Pompom Monster
  '70da3f90-0f71-404d-8174-fe7d85a79433', -- 14/06/2026 Performance OBEACH ANIVERSARIO
  'f78a698d-8392-4566-b59c-eb791f5816fb', -- 19/06/2026 Performance OBEACH
  'a01225f9-294e-4f6a-937d-8470f1e03bd9'  -- 26/06/2026 Performance OBEACH
);


-- 3. FACTURA Nº026 — COBRADA (4.664,00 € el 15/09/2026)
UPDATE public.invoices
SET
  status = 'pending',
  client_id = '5b1c5f25-8388-4aa1-9d57-d6e331fca365',
  issue_date = '2026-07-20',
  base_cents = 440000,
  tax_cents = 92400,
  retention_cents = 66000,
  total_cents = 466400,
  concept = 'Performances OBEACH — Julio 2026 (03/07, 10/07, 17/07, 24/07, 31/07 — 5 días x 880 € = 4.400 € base)',
  notes = 'Factura 026 COBRADA el 15/09/2026 via Transferencia bancaria. Total recibido: 4.664,00 €.',
  updated_at = NOW()
WHERE id = 'dc4ae2fc-e222-461a-a2a0-d756ac5491f4';

-- Delete any previous duplicate payment for 026 to ensure idempotency
DELETE FROM public.invoice_payments WHERE invoice_id = 'dc4ae2fc-e222-461a-a2a0-d756ac5491f4';

-- Insert exact payment for Factura 026
INSERT INTO public.invoice_payments (
  organization_id, invoice_id, payment_date, amount_cents, currency, method, reference, note, created_by
) VALUES (
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  'dc4ae2fc-e222-461a-a2a0-d756ac5491f4',
  '2026-09-15',
  466400,
  'EUR',
  'Transferencia bancaria',
  'Factura 026',
  'Cobro bancario verificado fecha 15/09/2026. Performances OBEACH Julio 2026',
  'afaa92ff-b00c-4fcf-9d1b-3155d18e370e'
);

-- Update events tied to Factura 026 as client_paid = true
UPDATE public.events
SET 
  client_id = '5b1c5f25-8388-4aa1-9d57-d6e331fca365',
  invoice_number = '026',
  client_paid = true,
  updated_at = NOW()
WHERE id IN (
  '169a62c3-99f6-4c1d-91ec-5d1f547e0ea7', -- 03/07/2026
  '90f206d0-4561-4580-9457-2435eb29353f', -- 10/07/2026
  '651ab71d-97e8-4597-a04f-328fa8b6acf3', -- 17/07/2026
  'd31abe57-d35c-43fa-81d5-c03679ccafc2', -- 24/07/2026
  '31621e13-f218-4c21-bfdd-e2a17a30442e'  -- 31/07/2026
);


-- 4. COBRO RECIBIDO PENDIENTE DE IDENTIFICAR (2.798,40 € el 15/09/2026)
DELETE FROM public.bank_movements 
WHERE original_reference = 'TRANSFERENCIA ICE MOUNTAIN IBIZA SL 15/09/2026' OR source_key = 'bank:icemountain:2026-09-15:279840';

INSERT INTO public.bank_movements (
  organization_id,
  source_key,
  source_hash,
  fingerprint,
  occurrence,
  payment_date,
  amount_cents,
  currency,
  original_reference,
  original_concept,
  source_file,
  source_sheet,
  source_row,
  source_data,
  supplier_id,
  talent_id,
  event_id,
  expected_cents,
  status,
  issues,
  resolution_note,
  created_by
) VALUES (
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  'bank:icemountain:2026-09-15:279840',
  'c5c63d9c7efc858b57f7c1666273eb14184b1f179c41c728b15fd1c331410c24',
  'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90',
  1,
  '2026-09-15',
  279840,
  'EUR',
  'TRANSFERENCIA ICE MOUNTAIN IBIZA SL 15/09/2026',
  'Cobro de 2.798,40 € recibido de ICE MOUNTAIN IBIZA SL (Pendiente de asignar a factura)',
  'Extracto Bancario 15/09/2026',
  'Cobros recibidos',
  1,
  '{"remitente": "ICE MOUNTAIN IBIZA SL", "client_id": "5b1c5f25-8388-4aa1-9d57-d6e331fca365", "posible_base": 264000, "posible_iva": 55440, "posible_irpf": 39600}'::jsonb,
  NULL,
  NULL,
  NULL,
  279840,
  'unmatched',
  ARRAY['identity_review'],
  'COBRO RECIBIDO — PENDIENTE DE ASIGNAR A FACTURA. Fecha 15/09/2026. Importe: 2.798,40 €. Remitente: ICE MOUNTAIN IBIZA SL. Posible coincidencia matemática: 3 performances @ 880 € (2.640 € base + 554,40 € IVA - 396,00 € IRPF).',
  'afaa92ff-b00c-4fcf-9d1b-3155d18e370e'
);

COMMIT;
