import { execSync } from 'child_process';
import fs from 'fs';

function runQuery(sql) {
  const cmd = `npx supabase db query --linked "${sql.replace(/"/g, '\\"')}"`;
  const out = execSync(cmd, { encoding: 'utf-8', cwd: process.cwd() });
  const match = out.match(/\{[\s\S]*"rows"[\s\S]*\}/);
  if (!match) return [];
  const parsed = JSON.parse(match[0]);
  return parsed.rows || [];
}

function runExec(sql) {
  const tmpFile = 'scratch/tmp_merge_query.sql';
  fs.writeFileSync(tmpFile, sql, 'utf-8');
  const cmd = `npx supabase db query --linked -f ${tmpFile}`;
  execSync(cmd, { encoding: 'utf-8', cwd: process.cwd() });
  if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
}

async function auditAndMergeClients() {
  console.log('Auditing clients for duplicates...');

  // Query all clients with their counts
  const sqlSelect = `
    SELECT 
      c.id,
      c.company_name,
      c.company,
      c.tax_id,
      c.email,
      c.phone,
      c.contact_name,
      c.city,
      c.country,
      c.billing_address,
      c.postal_code,
      c.province,
      c.fiscal_data,
      c.notes,
      c.created_at,
      (SELECT COUNT(*) FROM public.events e WHERE e.client_id = c.id) as event_count,
      (SELECT COUNT(*) FROM public.invoices i WHERE i.client_id = c.id) as invoice_count
    FROM public.clients c
    ORDER BY c.company_name ASC;
  `;

  const clients = runQuery(sqlSelect);
  console.log(`Total clients in database: ${clients.length}`);

  const normalize = (name) => {
    if (!name) return '';
    return name
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\b(s\.?l\.?|l\.?l\.?c\.?|s\.?a\.?|inc\.?|ltd\.?)\b/g, '')
      .replace(/[^a-z0-9]/g, '')
      .trim();
  };

  // Group by normalized name, tax_id, or email
  const groups = {};

  clients.forEach(client => {
    let key = '';
    const normName = normalize(client.company_name || client.company);
    const taxId = (client.tax_id || '').trim().toUpperCase();
    const email = (client.email || '').trim().toLowerCase();

    if (taxId && taxId !== '' && taxId !== 'N/A' && taxId.length > 3) {
      key = 'TAX:' + taxId;
    } else if (normName) {
      key = 'NAME:' + normName;
    } else if (email && email.includes('@')) {
      key = 'EMAIL:' + email;
    }

    if (key) {
      if (!groups[key]) groups[key] = [];
      groups[key].push(client);
    }
  });

  const duplicateGroups = Object.values(groups).filter(g => g.length > 1);
  console.log(`Found ${duplicateGroups.length} candidate duplicate client groups.`);

  let mergedCount = 0;
  let reallocatedEvents = 0;

  duplicateGroups.forEach(group => {
    // Sort group to pick canonical client:
    // 1. Most events + invoices
    // 2. Has tax_id / company / fiscal_data
    // 3. Earliest created_at
    group.sort((a, b) => {
      const scoreA = Number(a.event_count || 0) * 10 + Number(a.invoice_count || 0) * 10 + (a.tax_id ? 5 : 0) + (a.company ? 3 : 0);
      const scoreB = Number(b.event_count || 0) * 10 + Number(b.invoice_count || 0) * 10 + (b.tax_id ? 5 : 0) + (b.company ? 3 : 0);
      return scoreB - scoreA;
    });

    const canonical = group[0];
    const duplicates = group.slice(1);

    console.log(`\nMerging into Canonical Client: "${canonical.company_name}" (${canonical.id})`);
    console.log(`Duplicates to merge (${duplicates.length}):`, duplicates.map(d => `"${d.company_name}" (${d.id})`).join(', '));

    let updateFields = [];
    let sqlStatements = [];

    // Merge missing fields from duplicates into canonical
    let mergedCompany_name = canonical.company_name;
    let mergedCompany = canonical.company;
    let mergedTax_id = canonical.tax_id;
    let mergedEmail = canonical.email;
    let mergedPhone = canonical.phone;
    let mergedContact_name = canonical.contact_name;
    let mergedCity = canonical.city;
    let mergedBilling_address = canonical.billing_address;
    let mergedFiscal_data = canonical.fiscal_data;
    let mergedNotes = canonical.notes || '';

    duplicates.forEach(dup => {
      if (!mergedCompany && dup.company) mergedCompany = dup.company;
      if (!mergedTax_id && dup.tax_id) mergedTax_id = dup.tax_id;
      if (!mergedEmail && dup.email) mergedEmail = dup.email;
      if (!mergedPhone && dup.phone) mergedPhone = dup.phone;
      if (!mergedContact_name && dup.contact_name) mergedContact_name = dup.contact_name;
      if (!mergedCity && dup.city) mergedCity = dup.city;
      if (!mergedBilling_address && dup.billing_address) mergedBilling_address = dup.billing_address;
      if (!mergedFiscal_data && dup.fiscal_data) mergedFiscal_data = dup.fiscal_data;

      if (dup.notes && !mergedNotes.includes(dup.notes)) {
        mergedNotes = (mergedNotes ? mergedNotes + ' | ' : '') + dup.notes;
      }
    });

    // SQL to update canonical client
    const safeEsc = (val) => val == null ? 'NULL' : `'${String(val).replace(/'/g, "''")}'`;

    const updateCanonicalSql = `
      UPDATE public.clients
      SET company = ${safeEsc(mergedCompany)},
          tax_id = ${safeEsc(mergedTax_id)},
          email = ${safeEsc(mergedEmail)},
          phone = ${safeEsc(mergedPhone)},
          contact_name = ${safeEsc(mergedContact_name)},
          city = ${safeEsc(mergedCity)},
          billing_address = ${safeEsc(mergedBilling_address)},
          fiscal_data = ${safeEsc(mergedFiscal_data)},
          notes = ${safeEsc(mergedNotes)},
          updated_at = NOW()
      WHERE id = '${canonical.id}';
    `;
    sqlStatements.push(updateCanonicalSql);

    // Reassign relations for each duplicate
    duplicates.forEach(dup => {
      reallocatedEvents += Number(dup.event_count || 0);

      sqlStatements.push(`UPDATE public.events SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`UPDATE public.invoices SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`UPDATE public.proposals SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`UPDATE public.client_contacts SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`UPDATE public.tasks SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`UPDATE public.leads SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`UPDATE public.opportunities SET client_id = '${canonical.id}' WHERE client_id = '${dup.id}';`);
      sqlStatements.push(`DELETE FROM public.clients WHERE id = '${dup.id}';`);

      mergedCount++;
    });

    // Execute SQL for this group
    runExec(sqlStatements.join('\n'));
  });

  console.log(`\nClient audit & merge complete! Merged ${mergedCount} duplicate client profiles, reallocated ${reallocatedEvents} events.`);
}

auditAndMergeClients().catch(console.error);
