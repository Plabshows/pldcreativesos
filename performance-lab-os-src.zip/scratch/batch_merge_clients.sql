BEGIN;

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contacto@aotravelagency.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '6721b639-461c-446d-ae0c-849f555a4504';
    
UPDATE public.events SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
UPDATE public.invoices SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
UPDATE public.proposals SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
UPDATE public.client_contacts SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
UPDATE public.tasks SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
UPDATE public.leads SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
UPDATE public.opportunities SET client_id = '6721b639-461c-446d-ae0c-849f555a4504' WHERE client_id = 'fcff2609-f36a-4e54-87ec-718943ac846c';
DELETE FROM public.clients WHERE id = 'fcff2609-f36a-4e54-87ec-718943ac846c';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@arabiannightsperformances.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '5975c829-3269-4719-8212-4c1181a8b7f4';
    
UPDATE public.events SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
UPDATE public.invoices SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
UPDATE public.proposals SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
UPDATE public.client_contacts SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
UPDATE public.tasks SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
UPDATE public.leads SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
UPDATE public.opportunities SET client_id = '5975c829-3269-4719-8212-4c1181a8b7f4' WHERE client_id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';
DELETE FROM public.clients WHERE id = '8c9ad74f-6754-423a-ba9f-5c72e7936d2b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@arasarabia.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e';
    
UPDATE public.events SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
UPDATE public.invoices SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
UPDATE public.proposals SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
UPDATE public.client_contacts SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
UPDATE public.tasks SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
UPDATE public.leads SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
UPDATE public.opportunities SET client_id = '9cf4b29a-499e-42ec-905a-8e4a0109fc3e' WHERE client_id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';
DELETE FROM public.clients WHERE id = '20d86706-f99a-42b8-8f3a-4b9b27e4bdbb';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@artes.ae',
          phone = '+971 4 012 3456',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'a5817297-472e-4b17-bed1-30584f83f6ef';
    
UPDATE public.events SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
UPDATE public.invoices SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
UPDATE public.proposals SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
UPDATE public.client_contacts SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
UPDATE public.tasks SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
UPDATE public.leads SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
UPDATE public.opportunities SET client_id = 'a5817297-472e-4b17-bed1-30584f83f6ef' WHERE client_id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';
DELETE FROM public.clients WHERE id = 'a0453a6e-6ea4-4061-b947-e1d53d77c870';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@artvali.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '9d8732b2-7511-43df-bb9a-81274bb79cfd';
    
UPDATE public.events SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
UPDATE public.invoices SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
UPDATE public.proposals SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
UPDATE public.client_contacts SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
UPDATE public.tasks SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
UPDATE public.leads SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
UPDATE public.opportunities SET client_id = '9d8732b2-7511-43df-bb9a-81274bb79cfd' WHERE client_id = '022c3858-272c-46b8-aa2a-c486e5321d90';
DELETE FROM public.clients WHERE id = '022c3858-272c-46b8-aa2a-c486e5321d90';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@atollperformances.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '0a1cf9c9-294e-41fb-9e15-55501549e850';
    
UPDATE public.events SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
UPDATE public.invoices SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
UPDATE public.proposals SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
UPDATE public.client_contacts SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
UPDATE public.tasks SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
UPDATE public.leads SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
UPDATE public.opportunities SET client_id = '0a1cf9c9-294e-41fb-9e15-55501549e850' WHERE client_id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';
DELETE FROM public.clients WHERE id = '691e3c95-3c55-4db1-b482-9d44ccc128fc';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@aviondubai.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3';
    
UPDATE public.events SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.invoices SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.proposals SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.client_contacts SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.tasks SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.leads SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.opportunities SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
DELETE FROM public.clients WHERE id = 'a2e86c1d-89f3-41e4-8129-5a43723a8099';
UPDATE public.events SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
UPDATE public.invoices SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
UPDATE public.proposals SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
UPDATE public.client_contacts SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
UPDATE public.tasks SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
UPDATE public.leads SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
UPDATE public.opportunities SET client_id = '11fa8498-1fc0-41e2-a8de-6a4973cb03b3' WHERE client_id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';
DELETE FROM public.clients WHERE id = '6f9cda1b-55c0-47de-8cf8-faf03d39a4df';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@chameleonclubdubai.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '080ba973-e91f-4405-9eba-e581979ae3a7';
    
UPDATE public.events SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
UPDATE public.invoices SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
UPDATE public.proposals SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
UPDATE public.client_contacts SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
UPDATE public.tasks SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
UPDATE public.leads SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
UPDATE public.opportunities SET client_id = '080ba973-e91f-4405-9eba-e581979ae3a7' WHERE client_id = '75eee66f-b030-412e-816d-a736f9307eaa';
DELETE FROM public.clients WHERE id = '75eee66f-b030-412e-816d-a736f9307eaa';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@chameleon-nightclub.co.uk',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'b025e499-aa26-49c1-a130-644b8109df02';
    
UPDATE public.events SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
UPDATE public.invoices SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
UPDATE public.proposals SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
UPDATE public.client_contacts SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
UPDATE public.tasks SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
UPDATE public.leads SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
UPDATE public.opportunities SET client_id = 'b025e499-aa26-49c1-a130-644b8109df02' WHERE client_id = '9c394e44-cb32-455e-9143-67b8ce58f962';
DELETE FROM public.clients WHERE id = '9c394e44-cb32-455e-9143-67b8ce58f962';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'chicagos-basildon@delticgroup.co.uk',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'b6d8133f-4770-4d46-ba57-656a054538df';
    
UPDATE public.events SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
UPDATE public.invoices SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
UPDATE public.proposals SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
UPDATE public.client_contacts SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
UPDATE public.tasks SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
UPDATE public.leads SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
UPDATE public.opportunities SET client_id = 'b6d8133f-4770-4d46-ba57-656a054538df' WHERE client_id = 'b7e5d2c1-4419-4166-bd20-19052a160905';
DELETE FROM public.clients WHERE id = 'b7e5d2c1-4419-4166-bd20-19052a160905';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'bookings.cot80s@thenightleague.com',
          phone = '638525746',
          contact_name = 'Ben',
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7';
    
UPDATE public.events SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.invoices SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.proposals SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.client_contacts SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.tasks SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.leads SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.opportunities SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
DELETE FROM public.clients WHERE id = '8bdb196d-e799-4744-8319-dc9fe98fbaae';
UPDATE public.events SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.invoices SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.proposals SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.client_contacts SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.tasks SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.leads SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.opportunities SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
DELETE FROM public.clients WHERE id = '8afbadc6-ce36-4ec7-a9cd-fc9f24a418b3';
UPDATE public.events SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
UPDATE public.invoices SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
UPDATE public.proposals SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
UPDATE public.client_contacts SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
UPDATE public.tasks SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
UPDATE public.leads SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
UPDATE public.opportunities SET client_id = '3d0960e5-eb74-4c24-9113-8c73c9ca89b7' WHERE client_id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';
DELETE FROM public.clients WHERE id = 'a997ac7b-e8d3-478c-9af1-20db06a8d04a';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'reservations@cirquelesoirdubai.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8';
    
UPDATE public.events SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
UPDATE public.invoices SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
UPDATE public.proposals SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
UPDATE public.client_contacts SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
UPDATE public.tasks SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
UPDATE public.leads SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
UPDATE public.opportunities SET client_id = 'b59c248c-7d30-4f36-a988-a48cee9f32c8' WHERE client_id = '64c8533f-3c6d-466e-ade9-08848cb0292c';
DELETE FROM public.clients WHERE id = '64c8533f-3c6d-466e-ade9-08848cb0292c';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@cocosouthend.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0';
    
UPDATE public.events SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
UPDATE public.invoices SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
UPDATE public.proposals SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
UPDATE public.client_contacts SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
UPDATE public.tasks SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
UPDATE public.leads SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
UPDATE public.opportunities SET client_id = '0082596a-71f6-40b8-8cac-0d31bbb51cc0' WHERE client_id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';
DELETE FROM public.clients WHERE id = '29c53eb2-29cb-4a70-96a0-091c941edfd7';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@coralentertainment.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '25f7d65f-ce6d-4257-a925-202d7db970f6';
    
UPDATE public.events SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
UPDATE public.invoices SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
UPDATE public.proposals SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
UPDATE public.client_contacts SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
UPDATE public.tasks SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
UPDATE public.leads SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
UPDATE public.opportunities SET client_id = '25f7d65f-ce6d-4257-a925-202d7db970f6' WHERE client_id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';
DELETE FROM public.clients WHERE id = '9229e4c3-b9fd-484a-a4fb-32bbac2040f5';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'reservations@coyarestaurant.ae',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '9650b1e4-cf38-4922-873b-e256d4ca0986';
    
UPDATE public.events SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
UPDATE public.invoices SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
UPDATE public.proposals SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
UPDATE public.client_contacts SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
UPDATE public.tasks SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
UPDATE public.leads SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
UPDATE public.opportunities SET client_id = '9650b1e4-cf38-4922-873b-e256d4ca0986' WHERE client_id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';
DELETE FROM public.clients WHERE id = '277694fb-0477-4fb9-b8d9-4d4831a181ca';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@crearteevents.com',
          phone = '91 765 4321',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '60cea386-e553-48e2-891a-38c8ee474413';
    
UPDATE public.events SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
UPDATE public.invoices SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
UPDATE public.proposals SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
UPDATE public.client_contacts SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
UPDATE public.tasks SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
UPDATE public.leads SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
UPDATE public.opportunities SET client_id = '60cea386-e553-48e2-891a-38c8ee474413' WHERE client_id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';
DELETE FROM public.clients WHERE id = 'fcc0f1a2-78c6-4ad4-a26e-8b2a51937089';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@cwe.ae',
          phone = '+971 4 678 9012',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '526cf8da-7767-4933-9d66-fcbadb9417ec';
    
UPDATE public.events SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
UPDATE public.invoices SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
UPDATE public.proposals SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
UPDATE public.client_contacts SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
UPDATE public.tasks SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
UPDATE public.leads SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
UPDATE public.opportunities SET client_id = '526cf8da-7767-4933-9d66-fcbadb9417ec' WHERE client_id = 'df6a02ba-7add-4076-bc37-f89ede71f910';
DELETE FROM public.clients WHERE id = 'df6a02ba-7add-4076-bc37-f89ede71f910';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@cwt-meetings-events.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90';
    
UPDATE public.events SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.invoices SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.proposals SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.client_contacts SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.tasks SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.leads SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.opportunities SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '714b8af7-32b4-428c-9497-88434b1fca2c';
DELETE FROM public.clients WHERE id = '714b8af7-32b4-428c-9497-88434b1fca2c';
UPDATE public.events SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
UPDATE public.invoices SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
UPDATE public.proposals SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
UPDATE public.client_contacts SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
UPDATE public.tasks SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
UPDATE public.leads SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
UPDATE public.opportunities SET client_id = 'dbb40187-6974-4b4e-9dc9-cf2fb53ded90' WHERE client_id = '6383d8b0-570d-481a-b7de-aea1a1747588';
DELETE FROM public.clients WHERE id = '6383d8b0-570d-481a-b7de-aea1a1747588';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'dick@devignes.co.uk',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '774f59d6-a6c6-45de-8f9d-34940802a564';
    
UPDATE public.events SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
UPDATE public.invoices SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
UPDATE public.proposals SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
UPDATE public.client_contacts SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
UPDATE public.tasks SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
UPDATE public.leads SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
UPDATE public.opportunities SET client_id = '774f59d6-a6c6-45de-8f9d-34940802a564' WHERE client_id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';
DELETE FROM public.clients WHERE id = 'cc5fceed-076e-4e1a-937c-1dcc78d5fb42';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'alban@deeperibiza.com',
          phone = '+34 691 839 814',
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '40d9300f-b950-439f-9586-7e97c086c0b7';
    
UPDATE public.events SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.invoices SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.proposals SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.client_contacts SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.tasks SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.leads SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.opportunities SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
DELETE FROM public.clients WHERE id = 'f530ad1f-e2e0-4578-908f-ed8bfcd7015a';
UPDATE public.events SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
UPDATE public.invoices SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
UPDATE public.proposals SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
UPDATE public.client_contacts SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
UPDATE public.tasks SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
UPDATE public.leads SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
UPDATE public.opportunities SET client_id = '40d9300f-b950-439f-9586-7e97c086c0b7' WHERE client_id = 'a736b88e-7969-4c45-b976-57ee3799caae';
DELETE FROM public.clients WHERE id = 'a736b88e-7969-4c45-b976-57ee3799caae';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'admin@diversechoreography.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0';
    
UPDATE public.events SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
UPDATE public.invoices SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
UPDATE public.proposals SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
UPDATE public.client_contacts SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
UPDATE public.tasks SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
UPDATE public.leads SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
UPDATE public.opportunities SET client_id = 'a9e9fb20-2e53-48bc-8f3f-b6c1e9e6f0e0' WHERE client_id = '1f1f67d3-ba58-4034-91be-632fda95ada3';
DELETE FROM public.clients WHERE id = '1f1f67d3-ba58-4034-91be-632fda95ada3';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@dreammaldives.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '20c7c2de-e60f-4360-b033-e4aacab56ab4';
    
UPDATE public.events SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
UPDATE public.invoices SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
UPDATE public.proposals SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
UPDATE public.client_contacts SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
UPDATE public.tasks SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
UPDATE public.leads SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
UPDATE public.opportunities SET client_id = '20c7c2de-e60f-4360-b033-e4aacab56ab4' WHERE client_id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';
DELETE FROM public.clients WHERE id = 'ccc06de7-e082-47e5-bcb9-6694e5fa355c';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@dronexshow.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956';
    
UPDATE public.events SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.invoices SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.proposals SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.client_contacts SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.tasks SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.leads SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.opportunities SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
DELETE FROM public.clients WHERE id = '2ebafec2-1dce-49b9-83f6-4c2b553f86b7';
UPDATE public.events SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
UPDATE public.invoices SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
UPDATE public.proposals SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
UPDATE public.client_contacts SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
UPDATE public.tasks SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
UPDATE public.leads SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
UPDATE public.opportunities SET client_id = 'debfd3a7-c7d1-474d-8ce4-1003d6bbe956' WHERE client_id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';
DELETE FROM public.clients WHERE id = 'dd2fb749-a808-4e2a-a247-4391ed43ff31';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@eliteperformerssaudi.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'a83e99de-bb06-46c7-924b-c22957adde69';
    
UPDATE public.events SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
UPDATE public.invoices SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
UPDATE public.proposals SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
UPDATE public.client_contacts SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
UPDATE public.tasks SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
UPDATE public.leads SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
UPDATE public.opportunities SET client_id = 'a83e99de-bb06-46c7-924b-c22957adde69' WHERE client_id = '79aa1794-da48-429d-952e-078898f39709';
DELETE FROM public.clients WHERE id = '79aa1794-da48-429d-952e-078898f39709';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'hello@emerald.ae',
          phone = '+971 4 456 7890',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '464f3153-fd43-4e83-90da-6f992ffbb027';
    
UPDATE public.events SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.invoices SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.proposals SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.client_contacts SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.tasks SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.leads SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.opportunities SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
DELETE FROM public.clients WHERE id = 'c33b8315-4d1d-4c2f-89b8-9e9b9aeef497';
UPDATE public.events SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.invoices SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.proposals SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.client_contacts SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.tasks SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.leads SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.opportunities SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'a78cd855-c550-4519-8cab-42a80ac61229';
DELETE FROM public.clients WHERE id = 'a78cd855-c550-4519-8cab-42a80ac61229';
UPDATE public.events SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.invoices SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.proposals SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.client_contacts SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.tasks SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.leads SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.opportunities SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
DELETE FROM public.clients WHERE id = 'adaa149e-5369-434c-a6e1-09c2739ab48f';
UPDATE public.events SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
UPDATE public.invoices SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
UPDATE public.proposals SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
UPDATE public.client_contacts SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
UPDATE public.tasks SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
UPDATE public.leads SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
UPDATE public.opportunities SET client_id = '464f3153-fd43-4e83-90da-6f992ffbb027' WHERE client_id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';
DELETE FROM public.clients WHERE id = '49f2dc46-6724-48e0-a85c-ef9311d09f03';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'ramope2017@gmail.com',
          phone = NULL,
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'b4168636-9537-4308-a2da-a391e23d6b52';
    
UPDATE public.events SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.invoices SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.proposals SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.client_contacts SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.tasks SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.leads SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.opportunities SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
DELETE FROM public.clients WHERE id = '034fc5f7-0761-4adc-9beb-ede1f585fec9';
UPDATE public.events SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.invoices SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.proposals SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.client_contacts SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.tasks SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.leads SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.opportunities SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
DELETE FROM public.clients WHERE id = 'ca33c198-e564-4d11-bc96-b2f2ce4f4c21';
UPDATE public.events SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.invoices SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.proposals SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.client_contacts SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.tasks SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.leads SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.opportunities SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
DELETE FROM public.clients WHERE id = 'f7fd3c8c-4360-4770-9f47-7f03d33bb8bf';
UPDATE public.events SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
UPDATE public.invoices SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
UPDATE public.proposals SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
UPDATE public.client_contacts SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
UPDATE public.tasks SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
UPDATE public.leads SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
UPDATE public.opportunities SET client_id = 'b4168636-9537-4308-a2da-a391e23d6b52' WHERE client_id = '7657582f-d530-4abb-8e97-35cac0015b9f';
DELETE FROM public.clients WHERE id = '7657582f-d530-4abb-8e97-35cac0015b9f';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'Info@enterteinmentmatters.nl',
          phone = NULL,
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866';
    
UPDATE public.events SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.invoices SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.proposals SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.client_contacts SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.tasks SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.leads SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.opportunities SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
DELETE FROM public.clients WHERE id = 'd2c8dfdc-8cd2-44e0-ab5b-61944b44bd26';
UPDATE public.events SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
UPDATE public.invoices SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
UPDATE public.proposals SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
UPDATE public.client_contacts SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
UPDATE public.tasks SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
UPDATE public.leads SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
UPDATE public.opportunities SET client_id = 'f2ea2062-07ee-4a36-89ff-0d45a2a9e866' WHERE client_id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';
DELETE FROM public.clients WHERE id = 'a7abab8e-9d4e-472d-8f85-1056431db93f';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@euroviajes.com.uy',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '683886a6-2f99-4286-b881-fe22f00144e2';
    
UPDATE public.events SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
UPDATE public.invoices SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
UPDATE public.proposals SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
UPDATE public.client_contacts SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
UPDATE public.tasks SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
UPDATE public.leads SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
UPDATE public.opportunities SET client_id = '683886a6-2f99-4286-b881-fe22f00144e2' WHERE client_id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';
DELETE FROM public.clients WHERE id = 'c3be2e5f-1ecd-4740-961f-9b75a6a0567b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@evaneos.es',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '1855f731-c8d8-42a3-ba63-01e6c62632a3';
    
UPDATE public.events SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
UPDATE public.invoices SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
UPDATE public.proposals SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
UPDATE public.client_contacts SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
UPDATE public.tasks SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
UPDATE public.leads SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
UPDATE public.opportunities SET client_id = '1855f731-c8d8-42a3-ba63-01e6c62632a3' WHERE client_id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';
DELETE FROM public.clients WHERE id = 'b5a3179a-0c77-46e7-b915-ee93bea4c818';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@eventisimo.com',
          phone = '95 123 6789',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1';
    
UPDATE public.events SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
UPDATE public.invoices SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
UPDATE public.proposals SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
UPDATE public.client_contacts SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
UPDATE public.tasks SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
UPDATE public.leads SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
UPDATE public.opportunities SET client_id = '09ad4820-cabc-4b42-90ad-8a2bdbf0e2b1' WHERE client_id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';
DELETE FROM public.clients WHERE id = 'fb3e480b-4929-478c-b5dc-9a7dc4155118';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@evolutiondubai.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd';
    
UPDATE public.events SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.invoices SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.proposals SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.client_contacts SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.tasks SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.leads SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.opportunities SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = 'ae238315-a349-4f76-8003-b0a975db5858';
DELETE FROM public.clients WHERE id = 'ae238315-a349-4f76-8003-b0a975db5858';
UPDATE public.events SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
UPDATE public.invoices SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
UPDATE public.proposals SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
UPDATE public.client_contacts SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
UPDATE public.tasks SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
UPDATE public.leads SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
UPDATE public.opportunities SET client_id = '38bb6719-eb6b-4cf1-92d2-08a5798b16cd' WHERE client_id = '06178824-1c5b-4597-88ef-9c666ecd6f23';
DELETE FROM public.clients WHERE id = '06178824-1c5b-4597-88ef-9c666ecd6f23';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@experienceseventsibiza.com',
          phone = '971 19 37 45',
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '81225d9b-daa2-4190-b5fc-541385980f3e';
    
UPDATE public.events SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.invoices SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.proposals SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.client_contacts SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.tasks SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.leads SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.opportunities SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
DELETE FROM public.clients WHERE id = '37e7d455-69f5-49e1-a2fc-7e5653cd2689';
UPDATE public.events SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
UPDATE public.invoices SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
UPDATE public.proposals SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
UPDATE public.client_contacts SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
UPDATE public.tasks SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
UPDATE public.leads SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
UPDATE public.opportunities SET client_id = '81225d9b-daa2-4190-b5fc-541385980f3e' WHERE client_id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';
DELETE FROM public.clients WHERE id = '7ddb8d33-6a50-4505-bfeb-f76a4d0eaac1';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@factoriadeideas.com',
          phone = '96 123 9876',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'c94a52d2-27ba-461c-b350-3ce856db7465';
    
UPDATE public.events SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
UPDATE public.invoices SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
UPDATE public.proposals SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
UPDATE public.client_contacts SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
UPDATE public.tasks SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
UPDATE public.leads SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
UPDATE public.opportunities SET client_id = 'c94a52d2-27ba-461c-b350-3ce856db7465' WHERE client_id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';
DELETE FROM public.clients WHERE id = '39caf56f-b2c7-4ab2-aa97-ccb70634904a';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@funstepsagency.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd';
    
UPDATE public.events SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.invoices SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.proposals SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.client_contacts SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.tasks SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.leads SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.opportunities SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
DELETE FROM public.clients WHERE id = '6db3ae66-5a2e-403e-a5ad-6f7f8a968f79';
UPDATE public.events SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
UPDATE public.invoices SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
UPDATE public.proposals SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
UPDATE public.client_contacts SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
UPDATE public.tasks SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
UPDATE public.leads SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
UPDATE public.opportunities SET client_id = '3826ba55-f24d-4449-a9cc-695f8b1f8dfd' WHERE client_id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';
DELETE FROM public.clients WHERE id = '07a87182-4bef-44a3-b2fe-17db0b938ee8';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@fusionartevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '1636a905-0675-47bd-b200-9f0baabf435c';
    
UPDATE public.events SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
UPDATE public.invoices SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
UPDATE public.proposals SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
UPDATE public.client_contacts SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
UPDATE public.tasks SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
UPDATE public.leads SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
UPDATE public.opportunities SET client_id = '1636a905-0675-47bd-b200-9f0baabf435c' WHERE client_id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';
DELETE FROM public.clients WHERE id = '523d74dc-2fa9-4f06-8069-ca3d3f6c2297';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@glamourentertainment.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '36b40a8d-838d-457b-9154-04062e30c61f';
    
UPDATE public.events SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
UPDATE public.invoices SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
UPDATE public.proposals SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
UPDATE public.client_contacts SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
UPDATE public.tasks SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
UPDATE public.leads SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
UPDATE public.opportunities SET client_id = '36b40a8d-838d-457b-9154-04062e30c61f' WHERE client_id = '613a3d56-0074-4522-b4df-082399e6d408';
DELETE FROM public.clients WHERE id = '613a3d56-0074-4522-b4df-082399e6d408';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@glitzandglowentertainment.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '692dc25f-70a4-4c15-a807-6f27edcab821';
    
UPDATE public.events SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
UPDATE public.invoices SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
UPDATE public.proposals SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
UPDATE public.client_contacts SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
UPDATE public.tasks SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
UPDATE public.leads SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
UPDATE public.opportunities SET client_id = '692dc25f-70a4-4c15-a807-6f27edcab821' WHERE client_id = '26d5d437-aab6-449b-82b7-5f8722458414';
DELETE FROM public.clients WHERE id = '26d5d437-aab6-449b-82b7-5f8722458414';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@globaleventsagency.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '06b3fa63-7f1f-471d-91e5-17225d570bf9';
    
UPDATE public.events SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.invoices SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.proposals SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.client_contacts SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.tasks SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.leads SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.opportunities SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
DELETE FROM public.clients WHERE id = '4a15cccb-ebb9-4724-9c23-6e4c89009c8f';
UPDATE public.events SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
UPDATE public.invoices SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
UPDATE public.proposals SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
UPDATE public.client_contacts SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
UPDATE public.tasks SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
UPDATE public.leads SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
UPDATE public.opportunities SET client_id = '06b3fa63-7f1f-471d-91e5-17225d570bf9' WHERE client_id = '41db2330-21af-4ad3-916d-46ff84d8f27e';
DELETE FROM public.clients WHERE id = '41db2330-21af-4ad3-916d-46ff84d8f27e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@globalevents.ae',
          phone = '+971 4 123 4567',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '8d733f97-f843-40ab-9677-40d97da87c6c';
    
UPDATE public.events SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
UPDATE public.invoices SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
UPDATE public.proposals SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
UPDATE public.client_contacts SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
UPDATE public.tasks SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
UPDATE public.leads SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
UPDATE public.opportunities SET client_id = '8d733f97-f843-40ab-9677-40d97da87c6c' WHERE client_id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';
DELETE FROM public.clients WHERE id = 'd5e0f49b-c2d4-4b5d-8f0c-33810ecd164a';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contact@gmevents.ae',
          phone = '+971 4 901 2345',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '75101421-dff8-4abb-85d4-a40aabb544f8';
    
UPDATE public.events SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
UPDATE public.invoices SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
UPDATE public.proposals SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
UPDATE public.client_contacts SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
UPDATE public.tasks SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
UPDATE public.leads SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
UPDATE public.opportunities SET client_id = '75101421-dff8-4abb-85d4-a40aabb544f8' WHERE client_id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';
DELETE FROM public.clients WHERE id = '1ad5c785-14b6-4fb9-ac03-60a6745c5c81';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@gmevents.ae',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '13c535e9-7c25-4e21-86fe-90c7cb0da079';
    
UPDATE public.events SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.invoices SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.proposals SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.client_contacts SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.tasks SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.leads SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.opportunities SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
DELETE FROM public.clients WHERE id = '32e76d97-bd03-4420-9bb5-9a15e41682c8';
UPDATE public.events SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
UPDATE public.invoices SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
UPDATE public.proposals SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
UPDATE public.client_contacts SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
UPDATE public.tasks SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
UPDATE public.leads SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
UPDATE public.opportunities SET client_id = '13c535e9-7c25-4e21-86fe-90c7cb0da079' WHERE client_id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';
DELETE FROM public.clients WHERE id = '881b04d3-3f51-4cfb-b9c2-285e5d53fa48';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@greatwallevents.ae',
          phone = '+971 4 890 1234',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66';
    
UPDATE public.events SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
UPDATE public.invoices SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
UPDATE public.proposals SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
UPDATE public.client_contacts SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
UPDATE public.tasks SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
UPDATE public.leads SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
UPDATE public.opportunities SET client_id = '87a580f7-054c-42bd-8a4e-c4823a6ddb66' WHERE client_id = '1030c642-632f-4381-a0e1-a3f8ce047a10';
DELETE FROM public.clients WHERE id = '1030c642-632f-4381-a0e1-a3f8ce047a10';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'support@grosvenorcasinos.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685';
    
UPDATE public.events SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
UPDATE public.invoices SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
UPDATE public.proposals SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
UPDATE public.client_contacts SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
UPDATE public.tasks SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
UPDATE public.leads SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
UPDATE public.opportunities SET client_id = 'ae678cbd-9cf1-467b-8286-bb7bfac46685' WHERE client_id = '28d2566e-8e34-4aed-976e-a7ab433495e2';
DELETE FROM public.clients WHERE id = '28d2566e-8e34-4aed-976e-a7ab433495e2';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'jefe.administracion@hrhibiza.com',
          phone = '637085065',
          contact_name = 'Moises',
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = 'Contacto importado: Moises · vibe2@hrhibiza.com · 637085065',
          updated_at = NOW()
      WHERE id = 'ecd15f95-009d-4840-8e65-c98bb7565d19';
    
UPDATE public.events SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.invoices SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.proposals SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.client_contacts SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.tasks SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.leads SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.opportunities SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
DELETE FROM public.clients WHERE id = 'cb36ebd1-109f-4c3d-81e1-b1004c52481c';
UPDATE public.events SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
UPDATE public.invoices SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
UPDATE public.proposals SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
UPDATE public.client_contacts SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
UPDATE public.tasks SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
UPDATE public.leads SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
UPDATE public.opportunities SET client_id = 'ecd15f95-009d-4840-8e65-c98bb7565d19' WHERE client_id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';
DELETE FROM public.clients WHERE id = '6599c6de-16f6-46c6-903f-18b99f70ea6b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@ifza.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '36958db3-3e83-40cf-b677-15dfe45c6510';
    
UPDATE public.events SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.invoices SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.proposals SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.client_contacts SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.tasks SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.leads SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.opportunities SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
DELETE FROM public.clients WHERE id = 'ce4e5cfb-6635-4358-8130-2ced30a66994';
UPDATE public.events SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
UPDATE public.invoices SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
UPDATE public.proposals SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
UPDATE public.client_contacts SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
UPDATE public.tasks SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
UPDATE public.leads SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
UPDATE public.opportunities SET client_id = '36958db3-3e83-40cf-b677-15dfe45c6510' WHERE client_id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';
DELETE FROM public.clients WHERE id = '919a5010-89e1-4ae1-bde4-d4d8274b2fbd';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@islandentertainment.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '7f621436-4e98-4110-bf06-f4f5e89fe766';
    
UPDATE public.events SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
UPDATE public.invoices SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
UPDATE public.proposals SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
UPDATE public.client_contacts SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
UPDATE public.tasks SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
UPDATE public.leads SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
UPDATE public.opportunities SET client_id = '7f621436-4e98-4110-bf06-f4f5e89fe766' WHERE client_id = 'd49c1973-7821-4a2b-81f3-670c86c85374';
DELETE FROM public.clients WHERE id = 'd49c1973-7821-4a2b-81f3-670c86c85374';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@jannatevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '65742124-9b9b-4c3c-850f-6da8648f35e8';
    
UPDATE public.events SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.invoices SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.proposals SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.client_contacts SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.tasks SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.leads SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.opportunities SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
DELETE FROM public.clients WHERE id = 'a1edba6c-c121-40c5-a4f5-630074f44fd8';
UPDATE public.events SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
UPDATE public.invoices SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
UPDATE public.proposals SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
UPDATE public.client_contacts SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
UPDATE public.tasks SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
UPDATE public.leads SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
UPDATE public.opportunities SET client_id = '65742124-9b9b-4c3c-850f-6da8648f35e8' WHERE client_id = 'b4bdce31-7b20-45df-b048-72183d188110';
DELETE FROM public.clients WHERE id = 'b4bdce31-7b20-45df-b048-72183d188110';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@jeddah-events.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6';
    
UPDATE public.events SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
UPDATE public.invoices SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
UPDATE public.proposals SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
UPDATE public.client_contacts SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
UPDATE public.tasks SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
UPDATE public.leads SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
UPDATE public.opportunities SET client_id = '571e523e-a9d6-4bbc-a8b1-96a2bff052f6' WHERE client_id = 'c8567413-3276-4e89-8029-52e7b7ca9869';
DELETE FROM public.clients WHERE id = 'c8567413-3276-4e89-8029-52e7b7ca9869';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@kasentertainment.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2';
    
UPDATE public.events SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
UPDATE public.invoices SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
UPDATE public.proposals SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
UPDATE public.client_contacts SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
UPDATE public.tasks SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
UPDATE public.leads SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
UPDATE public.opportunities SET client_id = '2c0895fa-f535-4f98-8d17-a082d67ac2f2' WHERE client_id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';
DELETE FROM public.clients WHERE id = '41cf7b9b-d835-47a7-8059-80d7b50d598e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@lagoonshows.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'cec14a81-2287-431a-885e-80381cb691c4';
    
UPDATE public.events SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
UPDATE public.invoices SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
UPDATE public.proposals SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
UPDATE public.client_contacts SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
UPDATE public.tasks SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
UPDATE public.leads SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
UPDATE public.opportunities SET client_id = 'cec14a81-2287-431a-885e-80381cb691c4' WHERE client_id = '99350039-16e2-4332-a898-8430d685b568';
DELETE FROM public.clients WHERE id = '99350039-16e2-4332-a898-8430d685b568';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@lifexperiences.com',
          phone = '+34 971 100 908 / +34 654 622 563',
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '5c86883e-9934-4861-aa8d-727a41834050';
    
UPDATE public.events SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.invoices SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.proposals SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.client_contacts SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.tasks SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.leads SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.opportunities SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
DELETE FROM public.clients WHERE id = 'e373830a-586c-402b-a0ea-ba7bc506cf10';
UPDATE public.events SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
UPDATE public.invoices SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
UPDATE public.proposals SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
UPDATE public.client_contacts SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
UPDATE public.tasks SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
UPDATE public.leads SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
UPDATE public.opportunities SET client_id = '5c86883e-9934-4861-aa8d-727a41834050' WHERE client_id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';
DELETE FROM public.clients WHERE id = 'febe2fe5-c040-4433-9bf9-10ef20b91aba';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@linkviva.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b';
    
UPDATE public.events SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.invoices SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.proposals SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.client_contacts SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.tasks SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.leads SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.opportunities SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
DELETE FROM public.clients WHERE id = 'a7523022-8bc6-46a1-9dbd-d875aad5dc05';
UPDATE public.events SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
UPDATE public.invoices SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
UPDATE public.proposals SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
UPDATE public.client_contacts SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
UPDATE public.tasks SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
UPDATE public.leads SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
UPDATE public.opportunities SET client_id = 'd83b6dad-426a-4a6b-8a72-29fa041dff0b' WHERE client_id = '12ee8803-533c-4450-8eab-e14a2bce032b';
DELETE FROM public.clients WHERE id = '12ee8803-533c-4450-8eab-e14a2bce032b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@lovingmaldivas.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '43f8568b-aa73-4877-95d6-81d2275a22bc';
    
UPDATE public.events SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
UPDATE public.invoices SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
UPDATE public.proposals SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
UPDATE public.client_contacts SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
UPDATE public.tasks SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
UPDATE public.leads SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
UPDATE public.opportunities SET client_id = '43f8568b-aa73-4877-95d6-81d2275a22bc' WHERE client_id = '5418793f-f899-4032-a621-ac369c22df53';
DELETE FROM public.clients WHERE id = '5418793f-f899-4032-a621-ac369c22df53';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contact@lumasky.show',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '69c29f16-afba-4781-b666-d7f7c7370e59';
    
UPDATE public.events SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.invoices SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.proposals SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.client_contacts SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.tasks SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.leads SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.opportunities SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
DELETE FROM public.clients WHERE id = 'ee3dec2e-6cca-45f8-809e-fee60cc67c03';
UPDATE public.events SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
UPDATE public.invoices SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
UPDATE public.proposals SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
UPDATE public.client_contacts SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
UPDATE public.tasks SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
UPDATE public.leads SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
UPDATE public.opportunities SET client_id = '69c29f16-afba-4781-b666-d7f7c7370e59' WHERE client_id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';
DELETE FROM public.clients WHERE id = '80cfac17-cc39-45ad-8b32-0f5551a1f58e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'hello@mn.ae',
          phone = '+971 4 789 0123',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '38073c65-d84a-4591-b986-d790ce786f72';
    
UPDATE public.events SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
UPDATE public.invoices SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
UPDATE public.proposals SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
UPDATE public.client_contacts SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
UPDATE public.tasks SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
UPDATE public.leads SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
UPDATE public.opportunities SET client_id = '38073c65-d84a-4591-b986-d790ce786f72' WHERE client_id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';
DELETE FROM public.clients WHERE id = '501e76be-cac2-45d1-8fe1-189d4b8776ec';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@magiceventsibiza.com',
          phone = '+34 971 19 85 62',
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80';
    
UPDATE public.events SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.invoices SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.proposals SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.client_contacts SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.tasks SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.leads SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.opportunities SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
DELETE FROM public.clients WHERE id = '3ac897f9-859d-49fa-b42d-80d59ffcd801';
UPDATE public.events SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
UPDATE public.invoices SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
UPDATE public.proposals SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
UPDATE public.client_contacts SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
UPDATE public.tasks SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
UPDATE public.leads SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
UPDATE public.opportunities SET client_id = 'dadd0502-aa17-405e-9ccf-fc47f36c2e80' WHERE client_id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';
DELETE FROM public.clients WHERE id = '8656d6f9-5c46-4f95-95de-5cf662d689f1';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@maldivasparadise.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'ec263de0-5d04-496c-a33a-5962dfeb7333';
    
UPDATE public.events SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
UPDATE public.invoices SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
UPDATE public.proposals SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
UPDATE public.client_contacts SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
UPDATE public.tasks SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
UPDATE public.leads SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
UPDATE public.opportunities SET client_id = 'ec263de0-5d04-496c-a33a-5962dfeb7333' WHERE client_id = '29258cb0-1d25-46e5-b94d-75f5948a8973';
DELETE FROM public.clients WHERE id = '29258cb0-1d25-46e5-b94d-75f5948a8973';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@maldivasviajes.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70';
    
UPDATE public.events SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
UPDATE public.invoices SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
UPDATE public.proposals SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
UPDATE public.client_contacts SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
UPDATE public.tasks SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
UPDATE public.leads SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
UPDATE public.opportunities SET client_id = 'b37a6497-00c8-4db6-9be1-a56ee46c1c70' WHERE client_id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';
DELETE FROM public.clients WHERE id = 'e29d95be-8910-4537-b78e-4bd7e67380c5';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@maldivesartists.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'c81be881-cd5d-40a2-9a65-8686194b7099';
    
UPDATE public.events SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
UPDATE public.invoices SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
UPDATE public.proposals SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
UPDATE public.client_contacts SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
UPDATE public.tasks SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
UPDATE public.leads SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
UPDATE public.opportunities SET client_id = 'c81be881-cd5d-40a2-9a65-8686194b7099' WHERE client_id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';
DELETE FROM public.clients WHERE id = 'bdcd82ea-c75a-41e5-9f11-6709a7ae041b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@maldivesevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d';
    
UPDATE public.events SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
UPDATE public.invoices SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
UPDATE public.proposals SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
UPDATE public.client_contacts SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
UPDATE public.tasks SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
UPDATE public.leads SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
UPDATE public.opportunities SET client_id = 'f80b62d1-62c4-4431-bceb-5bd326c5aa8d' WHERE client_id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';
DELETE FROM public.clients WHERE id = '4299e89c-6c42-43e9-ab17-ac72dd04a76e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@marcomsme.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '539f3c5a-a714-4e36-bbc1-31ce4df54566';
    
UPDATE public.events SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.invoices SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.proposals SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.client_contacts SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.tasks SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.leads SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.opportunities SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
DELETE FROM public.clients WHERE id = 'f004e592-c024-45ea-bebb-6194f1371d6f';
UPDATE public.events SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
UPDATE public.invoices SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
UPDATE public.proposals SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
UPDATE public.client_contacts SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
UPDATE public.tasks SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
UPDATE public.leads SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
UPDATE public.opportunities SET client_id = '539f3c5a-a714-4e36-bbc1-31ce4df54566' WHERE client_id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';
DELETE FROM public.clients WHERE id = '92d3bad9-c19f-4f45-99d2-a8d6cae96788';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@memoriesevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c';
    
UPDATE public.events SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
UPDATE public.invoices SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
UPDATE public.proposals SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
UPDATE public.client_contacts SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
UPDATE public.tasks SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
UPDATE public.leads SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
UPDATE public.opportunities SET client_id = '516d5f16-f1b0-44b8-b61c-cb4f39e2a54c' WHERE client_id = 'ef29b33e-115a-418d-a3ef-472644576b58';
DELETE FROM public.clients WHERE id = 'ef29b33e-115a-418d-a3ef-472644576b58';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@merevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'b8248970-d80d-430b-a445-483bd66f57e3';
    
UPDATE public.events SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.invoices SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.proposals SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.client_contacts SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.tasks SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.leads SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.opportunities SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
DELETE FROM public.clients WHERE id = 'd0fffde6-9d62-4242-bdad-765275d963e5';
UPDATE public.events SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
UPDATE public.invoices SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
UPDATE public.proposals SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
UPDATE public.client_contacts SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
UPDATE public.tasks SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
UPDATE public.leads SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
UPDATE public.opportunities SET client_id = 'b8248970-d80d-430b-a445-483bd66f57e3' WHERE client_id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';
DELETE FROM public.clients WHERE id = 'e93d3fd4-14e3-4a28-806f-e29b0c793b82';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@mosaiclive.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '0886ab34-92fa-49d5-972b-d36041c732a3';
    
UPDATE public.events SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.invoices SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.proposals SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.client_contacts SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.tasks SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.leads SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.opportunities SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
DELETE FROM public.clients WHERE id = '317f21a5-f3da-48be-bf48-7edb89b4294d';
UPDATE public.events SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
UPDATE public.invoices SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
UPDATE public.proposals SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
UPDATE public.client_contacts SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
UPDATE public.tasks SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
UPDATE public.leads SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
UPDATE public.opportunities SET client_id = '0886ab34-92fa-49d5-972b-d36041c732a3' WHERE client_id = 'ec841106-f51b-441f-b626-b63d5a445da3';
DELETE FROM public.clients WHERE id = 'ec841106-f51b-441f-b626-b63d5a445da3';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'eat@mrmiyagisdubai.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b';
    
UPDATE public.events SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
UPDATE public.invoices SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
UPDATE public.proposals SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
UPDATE public.client_contacts SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
UPDATE public.tasks SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
UPDATE public.leads SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
UPDATE public.opportunities SET client_id = 'dc73cfd2-e378-46e6-bc13-f8e41112264b' WHERE client_id = '87001e9b-5065-4d27-8072-d978489dd4c8';
DELETE FROM public.clients WHERE id = '87001e9b-5065-4d27-8072-d978489dd4c8';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@nasec.com.sa',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '51dcc053-305e-4cc7-b58c-608f346e7594';
    
UPDATE public.events SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
UPDATE public.invoices SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
UPDATE public.proposals SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
UPDATE public.client_contacts SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
UPDATE public.tasks SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
UPDATE public.leads SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
UPDATE public.opportunities SET client_id = '51dcc053-305e-4cc7-b58c-608f346e7594' WHERE client_id = 'b08d1fe5-d4af-4e68-b654-e30941792885';
DELETE FROM public.clients WHERE id = 'b08d1fe5-d4af-4e68-b654-e30941792885';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@nomadsmaldives.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab';
    
UPDATE public.events SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
UPDATE public.invoices SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
UPDATE public.proposals SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
UPDATE public.client_contacts SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
UPDATE public.tasks SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
UPDATE public.leads SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
UPDATE public.opportunities SET client_id = 'dc84aa59-a32f-4036-b26e-ec49ceaf81ab' WHERE client_id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';
DELETE FROM public.clients WHERE id = '1e4d409b-b436-4f10-929f-7ea3135ce98e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@oceanicentertainment.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '18b3616c-55ba-42d3-86bf-728d977de078';
    
UPDATE public.events SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
UPDATE public.invoices SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
UPDATE public.proposals SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
UPDATE public.client_contacts SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
UPDATE public.tasks SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
UPDATE public.leads SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
UPDATE public.opportunities SET client_id = '18b3616c-55ba-42d3-86bf-728d977de078' WHERE client_id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';
DELETE FROM public.clients WHERE id = 'a2e581ec-b48b-4602-a00c-98062d050ab9';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@oneworldevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6';
    
UPDATE public.events SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
UPDATE public.invoices SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
UPDATE public.proposals SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
UPDATE public.client_contacts SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
UPDATE public.tasks SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
UPDATE public.leads SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
UPDATE public.opportunities SET client_id = 'eec5ded7-3d98-4b41-aeae-bf9ad873c2e6' WHERE client_id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';
DELETE FROM public.clients WHERE id = 'ffd8b07c-22bd-45ba-a302-1c169f36533f';

      UPDATE public.clients
      SET company = 'UNIVERSO PACHA SA',
          tax_id = 'A87753935',
          email = 'noelia@pacha.com; emganiha@hotmail.com',
          phone = '691481506',
          contact_name = 'NOE',
          city = 'Ibiza',
          billing_address = 'Av. 8 de Agosto Nº27',
          fiscal_data = 'AV. 8 DE AGOSTO, Nº 27, 07800 IBIZA, BALEARES, CIF. A87753935
Destinatario en factura 027/2026 (transcripción original):
UNIVERSO PACHA SA
Av 8 De Agosto Nº27
07800 Ibiza, Baleares
A87753935',
          notes = 'Contacto importado: Rafa de Siria · rafa@wearefamily.es
---
Alias / marcas relacionadas: Pacha, Flower Power. Razón social: UNIVERSO PACHA SA.',
          updated_at = NOW()
      WHERE id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849';
    
UPDATE public.events SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.invoices SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.proposals SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.client_contacts SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.tasks SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.leads SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.opportunities SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
DELETE FROM public.clients WHERE id = '8a6c8403-acd5-47dc-bb3c-77f3a4155212';
UPDATE public.events SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.invoices SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.proposals SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.client_contacts SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.tasks SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.leads SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.opportunities SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
DELETE FROM public.clients WHERE id = '4e03079a-d588-4d2c-813a-0e98e36ec96f';
UPDATE public.events SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
UPDATE public.invoices SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
UPDATE public.proposals SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
UPDATE public.client_contacts SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
UPDATE public.tasks SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
UPDATE public.leads SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
UPDATE public.opportunities SET client_id = '2218b4bd-1ae7-4abf-ada4-e12caffc9849' WHERE client_id = '433f7a0b-a144-4c49-9054-60bb1a696557';
DELETE FROM public.clients WHERE id = '433f7a0b-a144-4c49-9054-60bb1a696557';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@panachemiddleeast.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '9216147a-2126-4d28-9346-b2cb2e75b9a3';
    
UPDATE public.events SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.invoices SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.proposals SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.client_contacts SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.tasks SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.leads SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.opportunities SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
DELETE FROM public.clients WHERE id = 'e3f0a478-7528-488e-a67e-1316bf9976a6';
UPDATE public.events SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
UPDATE public.invoices SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
UPDATE public.proposals SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
UPDATE public.client_contacts SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
UPDATE public.tasks SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
UPDATE public.leads SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
UPDATE public.opportunities SET client_id = '9216147a-2126-4d28-9346-b2cb2e75b9a3' WHERE client_id = 'ddf674fc-818e-457b-89fb-28277e96c239';
DELETE FROM public.clients WHERE id = 'ddf674fc-818e-457b-89fb-28277e96c239';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@paradiseperformers.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a';
    
UPDATE public.events SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
UPDATE public.invoices SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
UPDATE public.proposals SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
UPDATE public.client_contacts SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
UPDATE public.tasks SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
UPDATE public.leads SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
UPDATE public.opportunities SET client_id = '4f7e4743-25de-4ed2-8a32-9dfdd712c71a' WHERE client_id = '647d5938-b480-4859-b063-0f90f432f652';
DELETE FROM public.clients WHERE id = '647d5938-b480-4859-b063-0f90f432f652';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'marketing@pixcom.ae',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '222472ec-e841-4d58-9a7b-34c8e14b483f';
    
UPDATE public.events SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.invoices SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.proposals SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.client_contacts SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.tasks SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.leads SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.opportunities SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
DELETE FROM public.clients WHERE id = '6c25f5ca-1e0d-446d-aa4e-6f58b717e5b0';
UPDATE public.events SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
UPDATE public.invoices SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
UPDATE public.proposals SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
UPDATE public.client_contacts SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
UPDATE public.tasks SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
UPDATE public.leads SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
UPDATE public.opportunities SET client_id = '222472ec-e841-4d58-9a7b-34c8e14b483f' WHERE client_id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';
DELETE FROM public.clients WHERE id = 'e95d6c1f-7ba1-4ede-9c8f-84a08aedb16b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contact@plan3media.ae',
          phone = '+971 4 567 8901',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'ac695419-e5f8-4129-8534-3a977f664647';
    
UPDATE public.events SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
UPDATE public.invoices SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
UPDATE public.proposals SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
UPDATE public.client_contacts SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
UPDATE public.tasks SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
UPDATE public.leads SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
UPDATE public.opportunities SET client_id = 'ac695419-e5f8-4129-8534-3a977f664647' WHERE client_id = 'be163cfd-24fb-41be-b477-2f6474d09eff';
DELETE FROM public.clients WHERE id = 'be163cfd-24fb-41be-b477-2f6474d09eff';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@prg.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3';
    
UPDATE public.events SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.invoices SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.proposals SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.client_contacts SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.tasks SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.leads SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.opportunities SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'ba578dc3-368a-41b6-9227-488523700f9b';
DELETE FROM public.clients WHERE id = 'ba578dc3-368a-41b6-9227-488523700f9b';
UPDATE public.events SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
UPDATE public.invoices SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
UPDATE public.proposals SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
UPDATE public.client_contacts SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
UPDATE public.tasks SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
UPDATE public.leads SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
UPDATE public.opportunities SET client_id = '97b8b418-9bc0-45a0-96c4-94cc5661c3d3' WHERE client_id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';
DELETE FROM public.clients WHERE id = 'b4841cfa-57de-4749-915f-0fc200a24f2a';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@pulse-entertainment.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c';
    
UPDATE public.events SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
UPDATE public.invoices SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
UPDATE public.proposals SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
UPDATE public.client_contacts SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
UPDATE public.tasks SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
UPDATE public.leads SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
UPDATE public.opportunities SET client_id = '08aaeb48-8ae2-4e88-bc05-63f8860d405c' WHERE client_id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';
DELETE FROM public.clients WHERE id = '029ba9c5-6b7c-442b-959b-38b4b3740c50';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@sauditalenthub.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '1ef53f07-472d-4688-a28d-ad09fdb1281c';
    
UPDATE public.events SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
UPDATE public.invoices SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
UPDATE public.proposals SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
UPDATE public.client_contacts SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
UPDATE public.tasks SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
UPDATE public.leads SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
UPDATE public.opportunities SET client_id = '1ef53f07-472d-4688-a28d-ad09fdb1281c' WHERE client_id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';
DELETE FROM public.clients WHERE id = '3d3287a8-766a-40cb-b7c5-4448a17aa8c7';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@scarlettentertainment.com',
          phone = '91 123 4567',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '97764867-bf76-4389-bfee-4a092f891e27';
    
UPDATE public.events SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.invoices SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.proposals SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.client_contacts SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.tasks SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.leads SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.opportunities SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
DELETE FROM public.clients WHERE id = '4fd40159-896f-4b21-8864-d24f5ff49c15';
UPDATE public.events SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.invoices SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.proposals SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.client_contacts SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.tasks SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.leads SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.opportunities SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
DELETE FROM public.clients WHERE id = '5d30f3d1-99a3-4fa1-a785-80a134a40c39';
UPDATE public.events SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.invoices SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.proposals SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.client_contacts SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.tasks SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.leads SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.opportunities SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
DELETE FROM public.clients WHERE id = '02c11f0b-dc0e-4d06-bb7d-10b47044cd6a';
UPDATE public.events SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
UPDATE public.invoices SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
UPDATE public.proposals SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
UPDATE public.client_contacts SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
UPDATE public.tasks SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
UPDATE public.leads SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
UPDATE public.opportunities SET client_id = '97764867-bf76-4389-bfee-4a092f891e27' WHERE client_id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';
DELETE FROM public.clients WHERE id = 'e8471812-1a0f-496d-bb13-cd5ab8cc3eee';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@sensationclub.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'e0704d31-0f69-42a9-a533-36a0ed477559';
    
UPDATE public.events SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
UPDATE public.invoices SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
UPDATE public.proposals SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
UPDATE public.client_contacts SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
UPDATE public.tasks SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
UPDATE public.leads SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
UPDATE public.opportunities SET client_id = 'e0704d31-0f69-42a9-a533-36a0ed477559' WHERE client_id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';
DELETE FROM public.clients WHERE id = '79b7b970-b82e-4191-b6b6-ace7c1afc3e7';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@shuraa.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911';
    
UPDATE public.events SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.invoices SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.proposals SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.client_contacts SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.tasks SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.leads SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.opportunities SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '7d1b879f-f003-4326-b463-d43730308364';
DELETE FROM public.clients WHERE id = '7d1b879f-f003-4326-b463-d43730308364';
UPDATE public.events SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
UPDATE public.invoices SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
UPDATE public.proposals SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
UPDATE public.client_contacts SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
UPDATE public.tasks SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
UPDATE public.leads SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
UPDATE public.opportunities SET client_id = 'fca9141e-d44f-4e34-a2b2-2807e1d7f911' WHERE client_id = '0d791866-2964-43f0-8aea-58705f7e9a0a';
DELETE FROM public.clients WHERE id = '0d791866-2964-43f0-8aea-58705f7e9a0a';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@skyhigh.ae',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '201337c0-d5b6-4185-bd00-bc2b429c61cc';
    
UPDATE public.events SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.invoices SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.proposals SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.client_contacts SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.tasks SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.leads SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.opportunities SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
DELETE FROM public.clients WHERE id = '7d9c2614-9fb7-411f-b8b8-64ae78672a69';
UPDATE public.events SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
UPDATE public.invoices SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
UPDATE public.proposals SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
UPDATE public.client_contacts SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
UPDATE public.tasks SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
UPDATE public.leads SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
UPDATE public.opportunities SET client_id = '201337c0-d5b6-4185-bd00-bc2b429c61cc' WHERE client_id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';
DELETE FROM public.clients WHERE id = '87e578c3-2f8d-4439-9420-d87d4c497fa0';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contact@skyhightec.ae',
          phone = '+971 4 234 5678',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '3b32d2e0-785d-42f4-acfb-bab913ed300b';
    
UPDATE public.events SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
UPDATE public.invoices SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
UPDATE public.proposals SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
UPDATE public.client_contacts SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
UPDATE public.tasks SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
UPDATE public.leads SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
UPDATE public.opportunities SET client_id = '3b32d2e0-785d-42f4-acfb-bab913ed300b' WHERE client_id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';
DELETE FROM public.clients WHERE id = 'c3a62f11-3da6-4313-9a31-e974cd83ae83';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'contacto@sorensen.es',
          phone = '91 234 5678',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '846c5828-deb5-4186-abaa-52007ec6ae47';
    
UPDATE public.events SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
UPDATE public.invoices SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
UPDATE public.proposals SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
UPDATE public.client_contacts SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
UPDATE public.tasks SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
UPDATE public.leads SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
UPDATE public.opportunities SET client_id = '846c5828-deb5-4186-abaa-52007ec6ae47' WHERE client_id = '4f183a38-cdb5-4758-889c-9429369f816e';
DELETE FROM public.clients WHERE id = '4f183a38-cdb5-4758-889c-9429369f816e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'enquiries@spectraentertainment.net',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '4020b86a-63e7-4f3f-92cb-660050b287b6';
    
UPDATE public.events SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.invoices SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.proposals SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.client_contacts SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.tasks SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.leads SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.opportunities SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
DELETE FROM public.clients WHERE id = '1ae9cc41-5e5c-4e2e-bb51-c45a236e7838';
UPDATE public.events SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
UPDATE public.invoices SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
UPDATE public.proposals SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
UPDATE public.client_contacts SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
UPDATE public.tasks SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
UPDATE public.leads SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
UPDATE public.opportunities SET client_id = '4020b86a-63e7-4f3f-92cb-660050b287b6' WHERE client_id = 'bfa79ca2-26e5-4924-a433-405224120214';
DELETE FROM public.clients WHERE id = 'bfa79ca2-26e5-4924-a433-405224120214';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'anas@starprodevents.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '99e45541-420d-48dc-98f2-41aa82da45f1';
    
UPDATE public.events SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
UPDATE public.invoices SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
UPDATE public.proposals SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
UPDATE public.client_contacts SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
UPDATE public.tasks SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
UPDATE public.leads SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
UPDATE public.opportunities SET client_id = '99e45541-420d-48dc-98f2-41aa82da45f1' WHERE client_id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';
DELETE FROM public.clients WHERE id = '044ed3d2-4465-413c-81d0-55dd5f94ed86';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@streetsutd.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293';
    
UPDATE public.events SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
UPDATE public.invoices SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
UPDATE public.proposals SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
UPDATE public.client_contacts SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
UPDATE public.tasks SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
UPDATE public.leads SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
UPDATE public.opportunities SET client_id = 'dc4c0d23-f505-40b2-8fa9-eac55184d293' WHERE client_id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';
DELETE FROM public.clients WHERE id = 'a2bd1c3a-76d2-48b3-a798-8e79a80e5736';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'carin@studio-aproductions.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183';
    
UPDATE public.events SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
UPDATE public.invoices SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
UPDATE public.proposals SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
UPDATE public.client_contacts SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
UPDATE public.tasks SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
UPDATE public.leads SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
UPDATE public.opportunities SET client_id = 'd59eb61d-f02d-45f8-ae69-a6bd7d36a183' WHERE client_id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';
DELETE FROM public.clients WHERE id = '25a4f4da-cba5-4d87-9fe4-ee56032033d3';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'reception@sugarhutgroup.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'fe08f284-b9b8-44d9-b034-48a49b40bded';
    
UPDATE public.events SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
UPDATE public.invoices SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
UPDATE public.proposals SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
UPDATE public.client_contacts SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
UPDATE public.tasks SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
UPDATE public.leads SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
UPDATE public.opportunities SET client_id = 'fe08f284-b9b8-44d9-b034-48a49b40bded' WHERE client_id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';
DELETE FROM public.clients WHERE id = 'f58f43ef-bdc5-4a9e-8b3e-30f5f982a510';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@sunsetevents.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac';
    
UPDATE public.events SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
UPDATE public.invoices SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
UPDATE public.proposals SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
UPDATE public.client_contacts SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
UPDATE public.tasks SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
UPDATE public.leads SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
UPDATE public.opportunities SET client_id = 'e5ff4220-5068-4e91-a921-d6f2001d1eac' WHERE client_id = 'afff092f-c266-42cf-9abd-c0ac446136cc';
DELETE FROM public.clients WHERE id = 'afff092f-c266-42cf-9abd-c0ac446136cc';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'renata@sunsethospitality.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '7a1a976b-1dc4-45e6-92a6-97626da84c69';
    
UPDATE public.events SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
UPDATE public.invoices SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
UPDATE public.proposals SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
UPDATE public.client_contacts SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
UPDATE public.tasks SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
UPDATE public.leads SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
UPDATE public.opportunities SET client_id = '7a1a976b-1dc4-45e6-92a6-97626da84c69' WHERE client_id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';
DELETE FROM public.clients WHERE id = '15c73529-ee10-4a9f-8762-0f597efe3d1e';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'carlos@swagibizaclub.com',
          phone = '625795300',
          contact_name = 'Carlos',
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = 'Contacto importado: Carlos · carlos@swagibizaclub.com · 625795300',
          updated_at = NOW()
      WHERE id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2';
    
UPDATE public.events SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.invoices SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.proposals SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.client_contacts SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.tasks SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.leads SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.opportunities SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
DELETE FROM public.clients WHERE id = '3f397ace-83f6-4a34-b9d9-e2423a0b3319';
UPDATE public.events SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.invoices SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.proposals SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.client_contacts SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.tasks SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.leads SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.opportunities SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '0827190f-7086-4dba-9f4b-dba10900c3da';
DELETE FROM public.clients WHERE id = '0827190f-7086-4dba-9f4b-dba10900c3da';
UPDATE public.events SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.invoices SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.proposals SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.client_contacts SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.tasks SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.leads SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.opportunities SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
DELETE FROM public.clients WHERE id = '094551e4-cc7d-4dcc-b93d-1f7b96a62188';
UPDATE public.events SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
UPDATE public.invoices SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
UPDATE public.proposals SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
UPDATE public.client_contacts SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
UPDATE public.tasks SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
UPDATE public.leads SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
UPDATE public.opportunities SET client_id = '34a9d7e3-a091-4ad2-b20f-07578f37caa2' WHERE client_id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';
DELETE FROM public.clients WHERE id = 'f6b26ce2-9c14-4ce4-b5a8-d2cd97b94076';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@talents-productions.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf';
    
UPDATE public.events SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.invoices SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.proposals SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.client_contacts SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.tasks SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.leads SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.opportunities SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
DELETE FROM public.clients WHERE id = 'fabfd04a-2656-47e2-9c5a-c5c914c3d670';
UPDATE public.events SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
UPDATE public.invoices SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
UPDATE public.proposals SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
UPDATE public.client_contacts SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
UPDATE public.tasks SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
UPDATE public.leads SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
UPDATE public.opportunities SET client_id = 'f1f3843d-d2c4-441f-91d4-67a5440c03cf' WHERE client_id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';
DELETE FROM public.clients WHERE id = '2ed7c7b2-00f0-4052-8101-8574c7a8b98d';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'casting@tedgroup.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901';
    
UPDATE public.events SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
UPDATE public.invoices SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
UPDATE public.proposals SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
UPDATE public.client_contacts SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
UPDATE public.tasks SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
UPDATE public.leads SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
UPDATE public.opportunities SET client_id = '53e7449b-c59a-411f-a5ee-7e4d2ceb8901' WHERE client_id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';
DELETE FROM public.clients WHERE id = 'ca88a226-936e-4ff7-ae6d-c810918e13be';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@theentertainmentagency.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf';
    
UPDATE public.events SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
UPDATE public.invoices SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
UPDATE public.proposals SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
UPDATE public.client_contacts SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
UPDATE public.tasks SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
UPDATE public.leads SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
UPDATE public.opportunities SET client_id = 'dc4f94f5-41d8-46c8-a8b1-1a99a69d13bf' WHERE client_id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';
DELETE FROM public.clients WHERE id = '2d9fb6f6-f5d6-4a57-a645-20073f3c793c';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@theeventcompany.com',
          phone = '+971 4 345 6789',
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd';
    
UPDATE public.events SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.invoices SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.proposals SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.client_contacts SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.tasks SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.leads SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.opportunities SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'dc295367-5efa-42b9-a865-9a6e22808791';
DELETE FROM public.clients WHERE id = 'dc295367-5efa-42b9-a865-9a6e22808791';
UPDATE public.events SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.invoices SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.proposals SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.client_contacts SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.tasks SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.leads SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.opportunities SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
DELETE FROM public.clients WHERE id = 'f97c2d94-d402-45a6-a6f3-04bf85ff3a84';
UPDATE public.events SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
UPDATE public.invoices SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
UPDATE public.proposals SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
UPDATE public.client_contacts SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
UPDATE public.tasks SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
UPDATE public.leads SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
UPDATE public.opportunities SET client_id = 'e7b349f2-09e5-419c-96b8-865109cbf9dd' WHERE client_id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';
DELETE FROM public.clients WHERE id = '2bca8855-67d9-4a99-bd58-d08b8453a95c';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@time-entertainment.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb';
    
UPDATE public.events SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.invoices SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.proposals SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.client_contacts SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.tasks SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.leads SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.opportunities SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '32592f2d-0d01-4a49-9126-d996192294e2';
DELETE FROM public.clients WHERE id = '32592f2d-0d01-4a49-9126-d996192294e2';
UPDATE public.events SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.invoices SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.proposals SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.client_contacts SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.tasks SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.leads SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.opportunities SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
DELETE FROM public.clients WHERE id = 'beda9dd3-47f7-477d-9609-93503f23a32e';
UPDATE public.events SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
UPDATE public.invoices SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
UPDATE public.proposals SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
UPDATE public.client_contacts SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
UPDATE public.tasks SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
UPDATE public.leads SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
UPDATE public.opportunities SET client_id = '6131f6d9-7a52-4840-a89c-d4fa2047cddb' WHERE client_id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';
DELETE FROM public.clients WHERE id = '3634e6c8-20dc-44df-9f3b-feba6549f6c7';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@totalisimo.com',
          phone = '+34 971 30 24 90',
          contact_name = NULL,
          city = 'Ibiza',
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45';
    
UPDATE public.events SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.invoices SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.proposals SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.client_contacts SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.tasks SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.leads SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.opportunities SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
DELETE FROM public.clients WHERE id = 'c064c759-3056-43c1-b84e-1082eb7f66d9';
UPDATE public.events SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.invoices SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.proposals SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.client_contacts SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.tasks SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.leads SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.opportunities SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '50cddcb6-176f-4208-9981-310a712e53c8';
DELETE FROM public.clients WHERE id = '50cddcb6-176f-4208-9981-310a712e53c8';
UPDATE public.events SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.invoices SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.proposals SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.client_contacts SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.tasks SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.leads SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.opportunities SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
DELETE FROM public.clients WHERE id = 'c78324da-d787-439b-ad90-2f98e2b4b6a5';
UPDATE public.events SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.invoices SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.proposals SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.client_contacts SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.tasks SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.leads SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.opportunities SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = '1d912967-618b-409b-9b30-2f33045fd4aa';
DELETE FROM public.clients WHERE id = '1d912967-618b-409b-9b30-2f33045fd4aa';
UPDATE public.events SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
UPDATE public.invoices SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
UPDATE public.proposals SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
UPDATE public.client_contacts SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
UPDATE public.tasks SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
UPDATE public.leads SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
UPDATE public.opportunities SET client_id = '8c5e9a5d-f958-4ba6-a702-6ae89e209c45' WHERE client_id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';
DELETE FROM public.clients WHERE id = 'f8dcd4ed-175d-4fe9-bf97-7ff6f21e4c38';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@tropicalshows.mv',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'df6e8184-2cc7-468d-b418-f862ea814abc';
    
UPDATE public.events SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
UPDATE public.invoices SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
UPDATE public.proposals SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
UPDATE public.client_contacts SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
UPDATE public.tasks SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
UPDATE public.leads SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
UPDATE public.opportunities SET client_id = 'df6e8184-2cc7-468d-b418-f862ea814abc' WHERE client_id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';
DELETE FROM public.clients WHERE id = 'c3160040-d0bf-47cb-a6f6-e5bd0208cfce';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'casting@expocitydubai.ae',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8';
    
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
DELETE FROM public.clients WHERE id = '71090de6-048e-4c75-8e6e-b518c85d52f2';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
DELETE FROM public.clients WHERE id = 'b20c6167-4f55-43d3-a2e4-3cf3b6f8707d';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
DELETE FROM public.clients WHERE id = 'ea728656-3ddb-4591-aab9-2f8613a17660';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
DELETE FROM public.clients WHERE id = 'fb8e2190-afe6-4dcb-8e52-8c38ab50f3ab';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
DELETE FROM public.clients WHERE id = '486bae7a-ee1d-4638-987c-a9f6fe5790b5';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
DELETE FROM public.clients WHERE id = 'ca66b185-6ac3-4e2c-8391-65f2b1911fe4';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
DELETE FROM public.clients WHERE id = 'b6614205-9ae1-4af2-8184-1d3a59a1904e';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
DELETE FROM public.clients WHERE id = '4f3ca7ba-9f85-4dc8-b0a3-f412283a27f7';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
DELETE FROM public.clients WHERE id = '1f817ead-61c9-46b4-a162-7f5ac80c754a';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
DELETE FROM public.clients WHERE id = 'b43a198a-b7d5-4bce-b125-916e2bfa3cbd';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
DELETE FROM public.clients WHERE id = 'ec04a901-a7ea-472b-b61a-8b247a0333d4';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
DELETE FROM public.clients WHERE id = 'dfe90ca1-e8c6-4dd1-9859-9b6793ae6c1b';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
DELETE FROM public.clients WHERE id = '81a3ee3b-f0b2-439a-b1c6-ebf8af6edff4';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '23250273-c297-4f02-9536-545a1c30bee1';
DELETE FROM public.clients WHERE id = '23250273-c297-4f02-9536-545a1c30bee1';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
DELETE FROM public.clients WHERE id = '2a3f0774-63e6-4389-ab4a-a6d273508a57';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
DELETE FROM public.clients WHERE id = 'd46495fa-d405-49d1-97f3-36f43627dae9';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
DELETE FROM public.clients WHERE id = '4eb986fa-d1d3-4cce-ac2c-c8b8eea9190c';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
DELETE FROM public.clients WHERE id = '0168f5fb-7887-47dc-a377-8073d2c5f4f0';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
DELETE FROM public.clients WHERE id = 'da64c784-f153-4775-9bc6-6d31b8b0b6c5';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
DELETE FROM public.clients WHERE id = 'f5b879d8-0713-42e5-bce0-bb4a794dbc62';
UPDATE public.events SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
UPDATE public.invoices SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
UPDATE public.proposals SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
UPDATE public.client_contacts SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
UPDATE public.tasks SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
UPDATE public.leads SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
UPDATE public.opportunities SET client_id = '8e3f9ad4-2923-4a3b-9f01-e43d53b025b8' WHERE client_id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';
DELETE FROM public.clients WHERE id = '67a594c5-ca04-4443-8e74-1b7ee784c51b';

      UPDATE public.clients
      SET company = 'USHUAIA ENTERTAINMENT SL',
          tax_id = 'B57794620',
          email = 'accounts.ushuaia@thenightleague.com',
          phone = '639317627',
          contact_name = 'Romain',
          city = 'Ibiza',
          billing_address = 'Avenida Bartolomé Rosello, 18, 07800 Ibiza',
          fiscal_data = 'AV. BARTOLOME ROSELLO, 18, 07800 IBIZA BALEARES, CIF. B57794620
Destinatario en factura 032/2026 (transcripción original):
USHUAIA ENTERTAINMENT SL
Avenida Bartolomé Rosello, 18
07800 Ibiza- Spain
B.57794620',
          notes = 'Alias / proyectos relacionados: Ushuaïa, UNVRS, Paradise. Razón social: USHUAIA ENTERTAINMENT SL. | Contacto importado: Romain · romain@high-scream.com · 639317627
---
Alias / proyectos relacionados: Ushuaïa, UNVRS, Paradise. Razón social: USHUAIA ENTERTAINMENT SL.',
          updated_at = NOW()
      WHERE id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6';
    
UPDATE public.events SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
UPDATE public.invoices SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
UPDATE public.proposals SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
UPDATE public.client_contacts SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
UPDATE public.tasks SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
UPDATE public.leads SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
UPDATE public.opportunities SET client_id = '4c7efbf5-3bc9-47b1-addc-0a169fb216b6' WHERE client_id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';
DELETE FROM public.clients WHERE id = '8b29a623-5a1f-4ed0-b333-8c64e9fdea50';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@viajesrangali.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c';
    
UPDATE public.events SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
UPDATE public.invoices SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
UPDATE public.proposals SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
UPDATE public.client_contacts SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
UPDATE public.tasks SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
UPDATE public.leads SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
UPDATE public.opportunities SET client_id = '476d7a7d-6e67-499e-bb15-3e5a49325b6c' WHERE client_id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';
DELETE FROM public.clients WHERE id = 'fd18a900-6c9a-4f89-9edf-bbbb4f80f891';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'support@viator.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98';
    
UPDATE public.events SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.invoices SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.proposals SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.client_contacts SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.tasks SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.leads SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.opportunities SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'c8638190-2faf-44e9-b373-0372e90d064b';
DELETE FROM public.clients WHERE id = 'c8638190-2faf-44e9-b373-0372e90d064b';
UPDATE public.events SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
UPDATE public.invoices SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
UPDATE public.proposals SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
UPDATE public.client_contacts SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
UPDATE public.tasks SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
UPDATE public.leads SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
UPDATE public.opportunities SET client_id = 'aa3c56e0-3a6c-44ce-baa8-a55e43164a98' WHERE client_id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';
DELETE FROM public.clients WHERE id = 'a1078f24-84c1-43ec-b647-2c78697e14ac';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@vibrance-events.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '1141226d-101f-47f2-8702-e60312a09816';
    
UPDATE public.events SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
UPDATE public.invoices SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
UPDATE public.proposals SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
UPDATE public.client_contacts SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
UPDATE public.tasks SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
UPDATE public.leads SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
UPDATE public.opportunities SET client_id = '1141226d-101f-47f2-8702-e60312a09816' WHERE client_id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';
DELETE FROM public.clients WHERE id = '39b00fce-b241-47ed-801e-4dfaccf0d5c8';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'careers@whitelabel.ae',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = 'efd68a04-e891-43ef-97eb-75b050344ed3';
    
UPDATE public.events SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
UPDATE public.invoices SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
UPDATE public.proposals SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
UPDATE public.client_contacts SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
UPDATE public.tasks SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
UPDATE public.leads SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
UPDATE public.opportunities SET client_id = 'efd68a04-e891-43ef-97eb-75b050344ed3' WHERE client_id = 'f8dda91b-5398-4184-ba32-80662467741b';
DELETE FROM public.clients WHERE id = 'f8dda91b-5398-4184-ba32-80662467741b';

      UPDATE public.clients
      SET company = NULL,
          tax_id = '',
          email = 'info@XLDubai.com',
          phone = NULL,
          contact_name = NULL,
          city = NULL,
          billing_address = '',
          fiscal_data = NULL,
          notes = '',
          updated_at = NOW()
      WHERE id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d';
    
UPDATE public.events SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
UPDATE public.invoices SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
UPDATE public.proposals SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
UPDATE public.client_contacts SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
UPDATE public.tasks SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
UPDATE public.leads SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
UPDATE public.opportunities SET client_id = '13f4dd90-19b8-41c3-9b1a-ed628cdd3f2d' WHERE client_id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
DELETE FROM public.clients WHERE id = '78822918-37e9-4d10-b39c-bbc0c7475cc7';
COMMIT;