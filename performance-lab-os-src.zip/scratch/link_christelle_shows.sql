-- Link shows for Christelle 5 events in Mallorca
BEGIN;

-- Ensure DISCO BALLS (DB) show exists
INSERT INTO public.shows (id, organization_id, show_code, name, category, description, active)
VALUES (
  'e2b489a7-938b-4b12-b2a6-578d8a7c1b21',
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  'SHOW-DB',
  'DISCO BALLS (DB)',
  'Character',
  'Disco Balls performance show',
  true
) ON CONFLICT (organization_id, name) DO NOTHING;

-- Ensure MIRROR MEN show exists
INSERT INTO public.shows (id, organization_id, show_code, name, category, description, active)
VALUES (
  'f4a398b1-127c-4890-a54b-689c7d1e2f34',
  '191c90ad-5337-405e-9d1a-abae2ad8c70e',
  'SHOW-MIRROR-MEN',
  'MIRROR MEN',
  'Character',
  'Mirror Men performance show',
  true
) ON CONFLICT (organization_id, name) DO NOTHING;

-- Get show IDs
DO $$
DECLARE
  v_db_id uuid;
  v_mm_id uuid;
  v_e1 uuid;
  v_e2 uuid;
  v_e3 uuid;
  v_e4 uuid;
  v_e5 uuid;
BEGIN
  SELECT id INTO v_db_id FROM public.shows WHERE name ILIKE '%DISCO BALLS%' OR name ILIKE '%SHOW-DB%' OR name = 'DISCO BALLS (DB)' LIMIT 1;
  SELECT id INTO v_mm_id FROM public.shows WHERE name ILIKE '%MIRROR MEN%' OR name ILIKE '%SHOW-MIRROR-MEN%' LIMIT 1;

  SELECT id INTO v_e1 FROM public.events WHERE client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8' AND event_date = '2026-07-11' LIMIT 1;
  SELECT id INTO v_e2 FROM public.events WHERE client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8' AND event_date = '2026-07-16' LIMIT 1;
  SELECT id INTO v_e3 FROM public.events WHERE client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8' AND event_date = '2026-09-10' LIMIT 1;
  SELECT id INTO v_e4 FROM public.events WHERE client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8' AND event_date = '2026-09-20' LIMIT 1;
  SELECT id INTO v_e5 FROM public.events WHERE client_id = '9cb2684e-d804-4a7e-b4af-2f93e32730a8' AND event_date = '2026-09-25' LIMIT 1;

  IF v_db_id IS NOT NULL THEN
    IF v_e1 IS NOT NULL THEN
      INSERT INTO public.event_shows (organization_id, event_id, show_id, quantity)
      VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', v_e1, v_db_id, 2)
      ON CONFLICT DO NOTHING;
    END IF;

    IF v_e2 IS NOT NULL THEN
      INSERT INTO public.event_shows (organization_id, event_id, show_id, quantity)
      VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', v_e2, v_db_id, 2)
      ON CONFLICT DO NOTHING;
    END IF;

    IF v_e3 IS NOT NULL THEN
      INSERT INTO public.event_shows (organization_id, event_id, show_id, quantity)
      VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', v_e3, v_db_id, 2)
      ON CONFLICT DO NOTHING;
    END IF;

    IF v_e4 IS NOT NULL THEN
      INSERT INTO public.event_shows (organization_id, event_id, show_id, quantity)
      VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', v_e4, v_db_id, 2)
      ON CONFLICT DO NOTHING;
    END IF;

    IF v_e5 IS NOT NULL THEN
      INSERT INTO public.event_shows (organization_id, event_id, show_id, quantity)
      VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', v_e5, v_db_id, 2)
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  IF v_mm_id IS NOT NULL AND v_e5 IS NOT NULL THEN
    INSERT INTO public.event_shows (organization_id, event_id, show_id, quantity)
    VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', v_e5, v_mm_id, 2)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

COMMIT;
