BEGIN;

-- 1. DELETE the duplicate event for 12 Sep
DELETE FROM events WHERE id = '0ee5b3da-bf63-4bb6-bb66-e9cc48bc7f4f';

-- 2. UPDATE existing 12 SEP
UPDATE events SET 
  internal_notes = 'Venue y servicio exactos por confirmar.',
  updated_at = NOW()
WHERE id = 'd1211ad1-0480-4d6f-a8d9-984c1b2f3b6d';

-- 3. INSERT 1 AGO 2026 - Akuarela
INSERT INTO events (organization_id, event_code, event_date, event_name, venue, city, client_id, income_cents, requested_entertainment, status, client_paid)
VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', 'EV-' || gen_random_uuid(), '2026-08-01', 'AKUARELA', 'Akuarela', 'Valencia', '1d6a6a51-1163-4ffe-b9e3-3480dc23597c', 40000, '2 performers / animación', 'production', false);

-- 4. INSERT 7 AGO 2026 - Savana
INSERT INTO events (organization_id, event_code, event_date, event_name, venue, city, client_id, income_cents, requested_entertainment, status, client_paid)
VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', 'EV-' || gen_random_uuid(), '2026-08-07', 'SAVANA', 'Savana', 'Valencia', '1d6a6a51-1163-4ffe-b9e3-3480dc23597c', 40000, '2 chicas / animación + vestuario', 'production', false);

-- 5. INSERT 8 AGO 2026 - Akuarela
INSERT INTO events (organization_id, event_code, event_date, event_name, venue, city, client_id, income_cents, requested_entertainment, status, client_paid)
VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', 'EV-' || gen_random_uuid(), '2026-08-08', 'AKUARELA', 'Akuarela', 'Valencia', '1d6a6a51-1163-4ffe-b9e3-3480dc23597c', 40000, '2 performers / animación', 'production', false);

-- 6. INSERT 15 AGO 2026 - Akuarela
INSERT INTO events (organization_id, event_code, event_date, event_name, venue, city, client_id, income_cents, requested_entertainment, status, client_paid)
VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', 'EV-' || gen_random_uuid(), '2026-08-15', 'AKUARELA', 'Akuarela', 'Valencia', '1d6a6a51-1163-4ffe-b9e3-3480dc23597c', 30000, '2 chicas + vestuario', 'production', false);

-- 7. INSERT 22 AGO 2026 - Savana
INSERT INTO events (organization_id, event_code, event_date, event_name, venue, city, client_id, income_cents, requested_entertainment, status, client_paid)
VALUES ('191c90ad-5337-405e-9d1a-abae2ad8c70e', 'EV-' || gen_random_uuid(), '2026-08-22', 'SAVANA', 'Savana', 'Valencia', '1d6a6a51-1163-4ffe-b9e3-3480dc23597c', 16000, '2 chicas de imagen', 'production', false);

COMMIT;
