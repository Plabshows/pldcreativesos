module.exports=[75371,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crm_route_actions_06ak72o.js.map