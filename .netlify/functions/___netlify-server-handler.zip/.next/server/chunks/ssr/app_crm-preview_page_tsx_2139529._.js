module.exports=[30829,a=>{"use strict";var b=a.i(87924),c=a.i(72131);a.i(63746),a.s(["default",0,function(){let[a,d]=(0,c.useState)("leads");return(0,b.jsx)("p",{children:"La prueba local está disponible únicamente en desarrollo."})}])}];

//# sourceMappingURL=app_crm-preview_page_tsx_2139529._.js.map