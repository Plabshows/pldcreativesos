module.exports=[7288,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_crm-preview_page_actions_18j1xqw.js.map