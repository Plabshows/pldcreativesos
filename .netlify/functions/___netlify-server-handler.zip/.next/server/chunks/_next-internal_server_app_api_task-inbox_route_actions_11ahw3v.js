module.exports=[22240,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_task-inbox_route_actions_11ahw3v.js.map