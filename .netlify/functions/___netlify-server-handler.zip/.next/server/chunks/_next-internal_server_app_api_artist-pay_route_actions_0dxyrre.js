module.exports=[202,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artist-pay_route_actions_0dxyrre.js.map