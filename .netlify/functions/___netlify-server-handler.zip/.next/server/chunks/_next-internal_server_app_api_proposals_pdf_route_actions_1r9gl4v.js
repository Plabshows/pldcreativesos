module.exports=[5810,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proposals_pdf_route_actions_1r9gl4v.js.map