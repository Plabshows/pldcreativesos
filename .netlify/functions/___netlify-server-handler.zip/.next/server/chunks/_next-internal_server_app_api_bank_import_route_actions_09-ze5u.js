module.exports=[67720,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bank_import_route_actions_09-ze5u.js.map