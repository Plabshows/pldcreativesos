module.exports=[2277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_event-options_route_actions_0jdz2mb.js.map