module.exports=[79095,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client-insights_route_actions_1oaqo-b.js.map