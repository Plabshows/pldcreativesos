module.exports=[44945,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proposals_route_actions_1812uw1.js.map