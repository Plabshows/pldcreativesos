module.exports=[79946,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_financial-documents_route_actions_1iov0r9.js.map