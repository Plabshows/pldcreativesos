module.exports=[84987,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_work-tasks_route_actions_1ni2w9h.js.map