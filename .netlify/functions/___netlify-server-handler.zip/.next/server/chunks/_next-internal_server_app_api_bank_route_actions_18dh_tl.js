module.exports=[16571,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bank_route_actions_18dh_tl.js.map