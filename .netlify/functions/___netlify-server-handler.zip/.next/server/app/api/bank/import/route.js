var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bank/import/route.js")
R.c("server/chunks/[externals]__0bjc7vc._.js")
R.c("server/chunks/[root-of-the-server]__06fw1vk._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_bank_import_route_actions_09-ze5u.js")
R.m(32471)
module.exports=R.m(32471).exports
