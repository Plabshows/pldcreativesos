var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bank/route.js")
R.c("server/chunks/[root-of-the-server]__1ci_sco._.js")
R.c("server/chunks/_1ubqxx3._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_bank_route_actions_18dh_tl.js")
R.m(58273)
module.exports=R.m(58273).exports
