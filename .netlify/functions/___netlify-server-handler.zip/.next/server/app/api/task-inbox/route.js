var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/task-inbox/route.js")
R.c("server/chunks/[root-of-the-server]__1wtclmb._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_task-inbox_route_actions_11ahw3v.js")
R.m(50371)
module.exports=R.m(50371).exports
