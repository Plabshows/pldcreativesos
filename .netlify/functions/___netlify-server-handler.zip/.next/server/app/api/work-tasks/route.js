var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/work-tasks/route.js")
R.c("server/chunks/[root-of-the-server]__11mvhe0._.js")
R.c("server/chunks/_0z5mukm._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_work-tasks_route_actions_1ni2w9h.js")
R.m(11725)
module.exports=R.m(11725).exports
