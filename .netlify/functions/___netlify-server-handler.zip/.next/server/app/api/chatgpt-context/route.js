var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chatgpt-context/route.js")
R.c("server/chunks/[root-of-the-server]__0-vz1zb._.js")
R.c("server/chunks/_127fk4h._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_chatgpt-context_route_actions_0j5nwt_.js")
R.m(5090)
module.exports=R.m(5090).exports
