var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/invoices/route.js")
R.c("server/chunks/[root-of-the-server]__1ci_sco._.js")
R.c("server/chunks/_1vfj3e8._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_invoices_route_actions_0oj_rsc.js")
R.m(75275)
module.exports=R.m(75275).exports
