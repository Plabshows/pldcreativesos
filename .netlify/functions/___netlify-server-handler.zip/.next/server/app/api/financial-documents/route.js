var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/financial-documents/route.js")
R.c("server/chunks/[root-of-the-server]__0ckaww7._.js")
R.c("server/chunks/_1lh1gjs._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_next-internal_server_app_api_financial-documents_route_actions_1iov0r9.js")
R.m(93894)
module.exports=R.m(93894).exports
