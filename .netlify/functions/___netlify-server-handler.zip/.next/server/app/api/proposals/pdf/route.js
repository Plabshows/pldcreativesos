var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proposals/pdf/route.js")
R.c("server/chunks/[root-of-the-server]__0-vz1zb._.js")
R.c("server/chunks/_1bodoxr._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_proposals_pdf_route_actions_1r9gl4v.js")
R.m(85370)
module.exports=R.m(85370).exports
