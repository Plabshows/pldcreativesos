var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/proposals/route.js")
R.c("server/chunks/[root-of-the-server]__1l08_-k._.js")
R.c("server/chunks/_1t-syfs._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_proposals_route_actions_1812uw1.js")
R.m(91820)
module.exports=R.m(91820).exports
