var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/artist-pay/route.js")
R.c("server/chunks/[root-of-the-server]__1ci_sco._.js")
R.c("server/chunks/_0xwkt9w._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_artist-pay_route_actions_0dxyrre.js")
R.m(5583)
module.exports=R.m(5583).exports
