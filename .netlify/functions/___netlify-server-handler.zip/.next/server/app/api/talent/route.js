var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/talent/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/_1n27hfb._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_talent_route_actions_022p8_o.js")
R.m(36441)
module.exports=R.m(36441).exports
