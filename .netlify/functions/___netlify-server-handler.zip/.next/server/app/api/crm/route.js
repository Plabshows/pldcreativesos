var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/crm/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/_0g1sczd._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_crm_route_actions_06ak72o.js")
R.m(26943)
module.exports=R.m(26943).exports
