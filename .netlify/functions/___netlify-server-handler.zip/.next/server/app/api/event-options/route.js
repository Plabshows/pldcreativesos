var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/event-options/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/_1l6rfs3._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_event-options_route_actions_0jdz2mb.js")
R.m(59127)
module.exports=R.m(59127).exports
