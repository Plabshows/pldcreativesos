var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/client-insights/route.js")
R.c("server/chunks/[root-of-the-server]__17h-d1m._.js")
R.c("server/chunks/[root-of-the-server]__07t85n9._.js")
R.c("server/chunks/_0wlwwmq._.js")
R.c("server/chunks/_next-internal_server_app_api_client-insights_route_actions_1oaqo-b.js")
R.m(45366)
module.exports=R.m(45366).exports
