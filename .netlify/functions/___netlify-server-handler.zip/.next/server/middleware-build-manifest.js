globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/OaqU-SgUS8oK9L6j--pur/_buildManifest.js",
    "static/OaqU-SgUS8oK9L6j--pur/_ssgManifest.js",
    "static/OaqU-SgUS8oK9L6j--pur/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2tswzwt7g9k6a.js",
    "static/chunks/2j0gct3wkb5vf.js",
    "static/chunks/2d14vny2m6ra7.js",
    "static/chunks/turbopack-3sbn18-p600le.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
